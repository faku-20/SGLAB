#!/usr/bin/env bash
# Verifica que el repo tenga la estructura canónica (ver docs/superpowers/specs/2026-10-05-reorganizacion-repo-design.md)
set -u
cd "$(dirname "$0")/.." || exit 1

fallos=0
fallo() { echo "FALLA: $*"; fallos=$((fallos + 1)); }

debe_existir=(
    app/Models/Auth.php
    app/Models/Database.php
    app/Controllers/loginController.php
    app/views/menu_docente.php
    app/api/api_registro.php
    public/index.html
    public/views/login_usuario.html
    public/assets/js/main.js
    database/01-schema.sql
    database/02-init-users.sh
    docker/php/Dockerfile
    docker/php/php.ini
    scripts/linux/backup.sh
    scripts/windows/Registro.ps1
    doc/DOCKER_QUICK_START.md
)
for p in "${debe_existir[@]}"; do
    [ -e "$p" ] || fallo "falta $p"
done

no_debe_existir=(
    assets src sql sh ps LAB6
    public/Public public/Models public/vendor public/composer.phar
    public/Dockerfile public/docker-compose.yml
    docker-compose2.yaml "docker-compose copia.yaml"
    sglab.sql SqlQuery_1.sql env.example
    test_session.php test_session_read.php DOCKER_QUICK_START.md .env-example
)
for p in "${no_debe_existir[@]}"; do
    [ -e "$p" ] && fallo "sobra $p"
done

basura=$(git ls-files | grep -E '\.DS_Store$|\.log$|(^|/)vendor/')
[ -n "$basura" ] && fallo "archivos ignorables versionados:"$'\n'"$basura"

# Requires siempre relativos a __DIR__ (funcionan desde cualquier directorio de trabajo)
sin_dir=$(grep -rnE "require(_once)?[[:space:]]*\(?[[:space:]]*['\"]" app)
[ -n "$sin_dir" ] && fallo "require sin __DIR__:"$'\n'"$sin_dir"

# __DIR__ concatenado sin barra inicial ('/..')
sin_barra=$(grep -rnE "__DIR__ \. '[^/]" app)
[ -n "$sin_barra" ] && fallo "__DIR__ sin barra:"$'\n'"$sin_barra"

# .env vive en la raíz: desde app/<Carpeta>/ es __DIR__ . '/../../'
dotenv_mal=$(grep -rnE "createImmutable\(__DIR__ \. '/\.\./'\)|->load\(\)" app)
[ -n "$dotenv_mal" ] && fallo "Dotenv apunta mal o usa load():"$'\n'"$dotenv_mal"

# Usuarios de prueba que no existen en el seed
usuarios_viejos=$(grep -rnE "admin123|docente123" --exclude-dir=.git --exclude-dir=docs --exclude-dir=.superpowers --exclude-dir=vendor --exclude-dir=tests .)
[ -n "$usuarios_viejos" ] && fallo "usuarios de prueba inexistentes:"$'\n'"$usuarios_viejos"

# Rutas viejas o con casing incorrecto
viejas=$(grep -rnE "models/|controllers/|public-WEB|Models/auth\.php|'\.\./vendor|Public/" app public \
    --include='*.php' --include='*.html' --include='*.js' | grep -v 'jquery-3.7.1.js')
[ -n "$viejas" ] && fallo "rutas viejas:"$'\n'"$viejas"

# Cada controller, vista PHP y api de app/ tiene su puente en public/
for f in app/Controllers/*.php app/views/*.php app/api/*.php; do
    rel=${f#app/}
    esperado="<?php require __DIR__ . '/../../app/$rel';"
    puente="public/$rel"
    if [ ! -f "$puente" ]; then
        fallo "falta puente $puente"
    elif [ "$(cat "$puente")" != "$esperado" ]; then
        fallo "puente incorrecto $puente"
    fi
done

# Control de acceso: toda vista y controlador llama a requerirRolVista/requerirRolApi,
# salvo los que forman parte del login (públicos por definición)
publicos=" loginController.php githubAuthController.php logoutController.php error.php vinculacion_github.php "
for f in app/views/*.php app/Controllers/*.php; do
    case "$publicos" in *" $(basename "$f") "*) continue ;; esac
    grep -qE "requerirRol(Vista|Api)\(" "$f" || fallo "sin control de acceso: $f"
done

# Sin CORS abierto ni session_start propio (lo hace app/Core/entorno.php)
cors=$(grep -rn "Access-Control-Allow" app)
[ -n "$cors" ] && fallo "headers CORS:"$'\n'"$cors"
sesiones=$(grep -rn "session_start()" app/views app/Controllers)
[ -n "$sesiones" ] && fallo "session_start() fuera de entorno.php:"$'\n'"$sesiones"

# Nada de contraseñas, secretos TOTP ni sesiones en el log
fugas=$(grep -rnE 'print_r\(\$_(POST|SESSION)|error_log\("[^"]*\$(secret|qrCode)\b' app)
[ -n "$fugas" ] && fallo "datos sensibles en el log:"$'\n'"$fugas"

# La clave API vieja (commiteada) no puede seguir en el código
clave_vieja=$(grep -rn "TU_CLAVE_SECRETA" --exclude-dir=.git --exclude-dir=docs --exclude-dir=tests --exclude-dir=.superpowers --exclude-dir=vendor .)
[ -n "$clave_vieja" ] && fallo "clave API vieja en el código:"$'\n'"$clave_vieja"

[ "$fallos" -eq 0 ] || { echo "$fallos fallo(s)"; exit 1; }
echo "estructura OK"
