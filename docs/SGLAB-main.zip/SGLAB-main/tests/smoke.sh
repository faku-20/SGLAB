#!/usr/bin/env bash
# Pruebas de humo HTTP contra la app levantada con docker compose.
# Uso: bash tests/smoke.sh [BASE_URL]   (default http://localhost:8080)
source "$(dirname "$0")/lib.sh"

DOCENTE=/Controllers/DocenteController.php

# --- Entrada y assets ---
check_status / 200
check_status /views/login_usuario.html 200
check_status /assets/css/estilos.css 200
check_status /assets/js/main.js 200

# --- Lógica y secretos no expuestos ---
check_status /Models/Database.php 404
check_status /app/Models/Database.php 404
check_status /.env 404
check_status /composer.json 404
check_status /vendor/autoload.php 404

# --- Login con GitHub (redirige a la autorización OAuth) ---
check_redirect /Controllers/githubAuthController.php github.com/login/oauth/authorize

# --- Login ---
check_json POST /Controllers/loginController.php 'action=login&username=docente1&password=mala' '.success == false'
check_json GET "$DOCENTE?action=obtenerEstadisticas" '' '.success == false' 401
check_json POST /Controllers/loginController.php 'action=login&username=docente1&password=password' '.success == true'

# --- Docente con sesión ---
check_page /views/menu_docente.php
check_page /views/panel_docente_laboratorios.php
check_json GET "$DOCENTE?action=obtenerEstadisticas" '' '.success == true and (.data | has("total_laboratorios"))'
check_json GET "$DOCENTE?action=obtenerLaboratoriosConEquipos" '' '.success == true and (.data | type == "array")'
check_json GET "$DOCENTE?action=inexistente" '' '.success == false' 400
lab=$(curl -s -b "$COOKIES" "$BASE$DOCENTE?action=obtenerLaboratoriosConEquipos" | jq -r '.data[0].idLaboratorio // empty')
if [ -n "$lab" ]; then
    check_json POST "$DOCENTE?action=actualizarComentario" "{\"idLaboratorio\": $lab, \"comentario\": \"smoke test\"}" '.success == true'
else
    fallo "no hay laboratorios para probar actualizarComentario"
fi
check_json POST "$DOCENTE?action=actualizarComentario" '{"idLaboratorio": "x", "comentario": "a"}' '.success == false' 400

# --- Logout ---
check_redirect /Controllers/logoutController.php index.html
check_json GET "$DOCENTE?action=obtenerEstadisticas" '' '.success == false' 401

terminar "smoke OK"
