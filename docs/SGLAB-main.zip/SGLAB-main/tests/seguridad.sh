#!/usr/bin/env bash
# Pruebas de seguridad: entorno, control de acceso por rol, login, clave API, CORS.
# Uso: bash tests/seguridad.sh [BASE_URL]   (requiere el stack de docker compose levantado)
source "$(dirname "$0")/lib.sh"
cd "$(dirname "$0")/.." || exit 1

LOGIN=/Controllers/loginController.php
EQUIPOS=/Controllers/EquipoController.php
USUARIOS=/Controllers/usuariosController.php
REGISTROS=/Controllers/RegistroController.php
DOCENTE=/Controllers/DocenteController.php

# Cada bloque usa su propio cookie jar (una sesión distinta)
JARS=("$COOKIES")
trap 'rm -f "${JARS[@]}"' EXIT
nuevo_jar() { COOKIES=$(mktemp); JARS+=("$COOKIES"); }

login_docente() {
    check_json POST "$LOGIN" 'action=login&username=docente1&password=password' '.success == true'
}

# Secreto TOTP de sysadmin guardado en la base (vacío si todavía no configuró 2FA)
secreto_admin() {
    docker compose exec -T db sh -c 'mysql -N -uroot -p"$MYSQL_ROOT_PASSWORD" bddsglab6 \
        -e "SELECT secret_2fa FROM Usuarios WHERE username=\"sysadmin\""' 2>/dev/null | tr -d '\r'
}

# Código TOTP actual para un secreto (calculado con otphp dentro del contenedor)
totp_ahora() {
    docker compose exec -T web php -r 'require "vendor/autoload.php"; echo OTPHP\TOTP::create($argv[1])->now();' "$1"
}

# Login completo de sysadmin: contraseña + 2FA (setup la primera vez, verify después).
# Reintenta una vez por si el código cambió justo entre calcularlo y enviarlo.
login_admin() {
    local resp secreto accion codigo intento
    resp=$(curl -s -b "$COOKIES" -c "$COOKIES" -X POST \
        --data 'action=login&username=sysadmin&password=password' "$BASE$LOGIN")
    if [ "$(jq -r '.needs_setup' <<<"$resp")" = true ]; then
        secreto=$(jq -r '.secret' <<<"$resp"); accion=setup_2fa
    else
        secreto=$(secreto_admin); accion=verify_2fa
    fi
    for intento in 1 2; do
        codigo=$(totp_ahora "$secreto")
        resp=$(curl -s -b "$COOKIES" -c "$COOKIES" -X POST \
            --data "action=$accion&user_id=1&code=$codigo" "$BASE$LOGIN")
        if jq -e '.success == true' <<<"$resp" >/dev/null 2>&1; then
            ok "login admin ($accion)"; return 0
        fi
    done
    fallo "login admin ($accion): ${resp:0:200}"
}

# Sesión de estudiante (juan.perez, id 6) sembrada directamente en el contenedor:
# el login real de estudiantes pasa por GitHub y no se puede automatizar.
sesion_estudiante() {
    local id
    id=$(openssl rand -hex 16)
    docker compose exec -T web sh -c "printf 'usuario_id|i:6;idTipoUsuario|i:3;' > /var/lib/php/sessions/sess_$id \
        && chown www-data:www-data /var/lib/php/sessions/sess_$id"
    printf 'localhost\tFALSE\t/\tFALSE\t0\tPHPSESSID\t%s\n' "$id" >> "$COOKIES"
}

# PHPSESSID actual del cookie jar
sesion_id() { awk '$6 == "PHPSESSID" {print $7}' "$COOKIES" | tail -n 1; }

# GET <path> siguiendo redirects; ¿el HTML final contiene <texto>?
check_contenido() {
    if curl -s -L -b "$COOKIES" -c "$COOKIES" "$BASE$1" | grep -q "$2"; then
        ok "$1 contiene '$2'"
    else
        fallo "$1 no contiene '$2'"
    fi
}

# check_display_errors <APP_ENV|ausente> <0|1>
check_display_errors() {
    local valor=$1 esperado=$2 obtenido
    [ "$valor" = ausente ] && valor=""
    obtenido=$(docker compose exec -T -e APP_ENV="$valor" web php -r \
        'require "app/Core/entorno.php"; echo ini_get("display_errors") ? "1" : "0";' 2>&1 | tail -n 1)
    [ "$obtenido" = "$esperado" ] && ok "APP_ENV=${1} → display_errors $obtenido" \
        || fallo "APP_ENV=${1} → display_errors '$obtenido' (esperado $esperado)"
}

# --- Entorno ---
check_display_errors desarrollo 1
check_display_errors produccion 0
check_display_errors ausente 0

# --- Sin sesión ---
nuevo_jar
for v in menu_admin equipos usuarios menu_estudiante; do
    check_redirect "/views/$v.php" login_usuario.html
done
SIN_SESION='.success == false and .message == "No autenticado"'
check_json GET  "$EQUIPOS?action=obtenerTodos" '' "$SIN_SESION" 401
check_json POST "$EQUIPOS?action=crearEquipo" '{}' "$SIN_SESION" 401
check_json GET  "$USUARIOS?action=obtenerUsuarios" '' "$SIN_SESION" 401
check_json GET  "$REGISTROS?action=obtenerTodosRegistros" '' "$SIN_SESION" 401
check_json GET  "$REGISTROS?action=obtenerEquipos" '' "$SIN_SESION" 401

# --- Docente ---
nuevo_jar
login_docente
PROHIBIDO='.success == false and .message == "No autorizado"'
check_json GET  "$EQUIPOS?action=obtenerTodos" '' "$PROHIBIDO" 403
check_json POST "$EQUIPOS?action=crearEquipo" '{}' "$PROHIBIDO" 403
check_json GET  "$USUARIOS?action=obtenerUsuarios" '' "$PROHIBIDO" 403
check_json GET  "$REGISTROS?action=obtenerTodosRegistros" '' "$PROHIBIDO" 403
check_json GET  "$REGISTROS?action=obtenerEquipos" '' "$PROHIBIDO" 403
for v in menu_admin equipos usuarios menu_estudiante; do
    check_redirect "/views/$v.php" login_usuario.html
done
check_json GET "$DOCENTE?action=obtenerEstadisticas" '' '.success == true'

# --- Admin (contraseña + TOTP) ---
nuevo_jar
login_admin
for v in menu_admin equipos usuarios menu_docente panel_docente_laboratorios; do
    check_page "/views/$v.php"
done
check_json GET  "$EQUIPOS?action=obtenerTodos" '' '.success == true'
check_json GET  "$USUARIOS?action=obtenerUsuarios" '' '.success == true'
check_json GET  "$REGISTROS?action=obtenerTodosRegistros" '' '.success == true'
check_json GET  "$REGISTROS?action=obtenerEquipos" '' '.success == true'
check_json GET  "$DOCENTE?action=obtenerEstadisticas" '' '.success == true'
check_json POST "$REGISTROS?action=crearReporte" 'idEquipo=1&estado=1&descripcion=x' "$PROHIBIDO" 403
check_redirect /views/menu_estudiante.php login_usuario.html

# --- Estudiante (sesión sembrada) ---
nuevo_jar
sesion_estudiante
check_page /views/menu_estudiante.php
check_json GET "$REGISTROS?action=obtenerEquipos" '' '.success == true and (.data | length > 0)'
equipo=$(curl -s -b "$COOKIES" "$BASE$REGISTROS?action=obtenerEquipos" | jq -r '.data[0].idEquipo // empty')
check_json POST "$REGISTROS?action=crearReporte" \
    "idEquipo=${equipo:-1}&estado=1&descripcion=Reporte de prueba de seguridad.sh" '.success == true'
check_json GET "$EQUIPOS?action=obtenerTodos" '' "$PROHIBIDO" 403
check_json GET "$REGISTROS?action=obtenerTodosRegistros" '' "$PROHIBIDO" 403
for v in menu_admin equipos usuarios menu_docente; do
    check_redirect "/views/$v.php" login_usuario.html
done

# --- CORS: sin Access-Control-Allow-Origin ---
for path in "$LOGIN" "$EQUIPOS"; do
    if curl -s -D - -o /dev/null -X POST "$BASE$path" | grep -qi '^access-control-allow-origin'; then
        fallo "$path envía Access-Control-Allow-Origin"
    else
        ok "$path sin Access-Control-Allow-Origin"
    fi
done

# --- 2FA ligado a la sesión: no se puede saltear la contraseña ---
EXPIRADA='.success == false and .message == "Sesión de login expirada. Ingrese nuevamente usuario y contraseña."'
secreto=$(secreto_admin)
for accion in verify_2fa setup_2fa; do
    nuevo_jar
    check_json POST "$LOGIN" "action=$accion&user_id=1&code=$(totp_ahora "$secreto")" "$EXPIRADA"
done

# --- Fijación de sesión: el ID cambia al loguearse ---
nuevo_jar
check_json POST "$LOGIN" 'action=login&username=docente1&password=mala' '.success == false'
antes=$(sesion_id)
login_docente
[ -n "$antes" ] && [ "$antes" != "$(sesion_id)" ] && ok "docente: PHPSESSID cambia al loguearse" \
    || fallo "docente: PHPSESSID no cambia al loguearse ($antes)"
nuevo_jar
curl -s -o /dev/null -b "$COOKIES" -c "$COOKIES" -X POST \
    --data 'action=login&username=sysadmin&password=password' "$BASE$LOGIN"
antes=$(sesion_id)
login_admin
[ -n "$antes" ] && [ "$antes" != "$(sesion_id)" ] && ok "admin: PHPSESSID cambia tras el 2FA" \
    || fallo "admin: PHPSESSID no cambia tras el 2FA ($antes)"

# --- OAuth: el state se valida ---
OAUTH=/Controllers/githubAuthController.php
nuevo_jar
curl -s -o /dev/null -b "$COOKIES" -c "$COOKIES" "$BASE$OAUTH"   # paso 1: guarda oauth_state
check_redirect "$OAUTH?code=x&state=malo" views/error.php
check_contenido /views/error.php "no es válida o expiró"
nuevo_jar
check_redirect "$OAUTH?code=x" views/error.php
check_contenido /views/error.php "no es válida o expiró"

# --- Clave API (api_registro.php) ---
API=/api/api_registro.php
nuevo_jar
clave=$(grep -E '^API_KEY=' .env | cut -d= -f2-)
check_json POST "$API" 'x=1' '.mensaje == "Acceso no autorizado."' 401
EXTRA_HEADER="X-API-KEY: incorrecta" check_json POST "$API" 'x=1' '.mensaje == "Acceso no autorizado."' 401
EXTRA_HEADER="X-API-KEY: $clave" check_json GET "$API" '' '.mensaje == "Método no permitido."' 405
sin_clave=$(docker compose exec -T -e API_KEY= -e REQUEST_METHOD=POST -e HTTP_X_API_KEY= web \
    php app/api/api_registro.php 2>&1)
grep -q "API no configurada" <<<"$sin_clave" && ok "API_KEY vacía → 'API no configurada'" \
    || fallo "API_KEY vacía: ${sin_clave:0:200}"

# --- 2FA: límite de intentos (tras 5 códigos incorrectos hay que volver a poner la contraseña) ---
nuevo_jar
curl -s -o /dev/null -b "$COOKIES" -c "$COOKIES" -X POST \
    --data 'action=login&username=sysadmin&password=password' "$BASE$LOGIN"
for i in 1 2 3 4 5; do
    curl -s -o /dev/null -b "$COOKIES" -c "$COOKIES" -X POST --data 'action=verify_2fa&code=000000' "$BASE$LOGIN"
done
check_json POST "$LOGIN" "action=verify_2fa&code=$(totp_ahora "$(secreto_admin)")" "$EXPIRADA"

# --- Acciones destructivas solo por POST (un link GET no puede borrar nada) ---
nuevo_jar
login_admin
METODO='.success == false and .message == "Método no permitido"'
check_json GET "$EQUIPOS?action=darDeBaja&idEquipo=999999" '' "$METODO" 400
check_json GET "$EQUIPOS?action=reactivar&idEquipo=999999" '' "$METODO" 400
check_json GET "$USUARIOS?action=eliminarUsuario&id=999999" '' "$METODO" 400

# --- Errores de programación (TypeError, etc.): 500 genérico, sin rutas ni mensajes internos ---
salida=$(docker compose exec -T -e APP_ENV=produccion web php -r \
    'require "app/Core/respuestas.php"; responderExcepcion(new TypeError("fallo en /var/www/sglab/app/x.php"));')
jq -e '.success == false and .message == "Error interno del servidor" and (tostring | test("/var/www") | not)' \
    <<<"$salida" >/dev/null 2>&1 && ok "TypeError → 'Error interno del servidor' sin rutas" \
    || fallo "TypeError: ${salida:0:200}"

terminar "seguridad OK"
