#!/usr/bin/env bash
# Helpers compartidos por los tests HTTP (smoke.sh, seguridad.sh, errores.sh).
# Uso: source "$(dirname "$0")/lib.sh"   — BASE y COOKIES se pueden sobrescribir.
set -u
BASE=${1:-http://localhost:8080}
COOKIES=$(mktemp)
trap 'rm -f "$COOKIES"' EXIT

fallos=0
ok()    { echo "ok    $*"; }
fallo() { echo "FALLA $*"; fallos=$((fallos + 1)); }

# check_status <path> <codigo esperado>
check_status() {
    local code
    code=$(curl -s -o /dev/null -w '%{http_code}' -b "$COOKIES" -c "$COOKIES" "$BASE$1")
    [ "$code" = "$2" ] && ok "$1 → $code" || fallo "$1 → $code (esperado $2)"
}

# check_json <GET|POST> <path> <datos form-urlencoded o ''> <expresión jq> [codigo esperado]
check_json() {
    local method=$1 path=$2 data=$3 expr=$4 esperado=${5:-200} out body code
    out=$(mktemp)
    # EXTRA_HEADER (opcional): un header adicional, por ejemplo "X-API-KEY: ..."
    local extra=()
    [ -n "${EXTRA_HEADER:-}" ] && extra=(-H "$EXTRA_HEADER")
    if [ "$method" = POST ] && [ "${data:0:1}" = "{" ]; then
        code=$(curl -s -o "$out" -w '%{http_code}' -b "$COOKIES" -c "$COOKIES" ${extra[@]+"${extra[@]}"} -X POST \
            -H 'Content-Type: application/json' --data "$data" "$BASE$path")
    elif [ "$method" = POST ]; then
        code=$(curl -s -o "$out" -w '%{http_code}' -b "$COOKIES" -c "$COOKIES" ${extra[@]+"${extra[@]}"} -X POST --data "$data" "$BASE$path")
    else
        code=$(curl -s -o "$out" -w '%{http_code}' -b "$COOKIES" -c "$COOKIES" ${extra[@]+"${extra[@]}"} "$BASE$path")
    fi
    body=$(cat "$out"); rm -f "$out"
    if [ "$code" != "$esperado" ]; then
        fallo "$method $path → $code (esperado $esperado): ${body:0:200}"
    elif ! echo "$body" | jq -e "$expr" >/dev/null 2>&1; then
        fallo "$method $path: no cumple '$expr': ${body:0:200}"
    else
        ok "$method $path → $code, $expr"
    fi
}

# check_page <path>: 200 y sin avisos de PHP en el HTML
check_page() {
    local out code
    out=$(mktemp)
    code=$(curl -s -o "$out" -w '%{http_code}' -b "$COOKIES" -c "$COOKIES" "$BASE$1")
    if [ "$code" != 200 ]; then
        fallo "$1 → $code (esperado 200)"
    elif grep -qE '<b>(Warning|Notice|Fatal error|Deprecated)</b>' "$out"; then
        fallo "$1 → 200 pero con avisos de PHP: $(grep -oE '<b>(Warning|Notice|Fatal error|Deprecated)</b>:[^<]*' "$out" | head -1)"
    else
        ok "$1 → 200 sin avisos de PHP"
    fi
    rm -f "$out"
}

# check_redirect <path> <texto que debe contener el header Location>
check_redirect() {
    local res code loc
    res=$(curl -s -o /dev/null -w '%{http_code} %{redirect_url}' -b "$COOKIES" -c "$COOKIES" "$BASE$1")
    code=${res%% *}; loc=${res#* }
    if [ "$code" = 302 ] && [[ "$loc" == *"$2"* ]]; then
        ok "$1 → 302 $loc"
    else
        fallo "$1 → $code $loc (esperado 302 a *$2)"
    fi
}

# terminar [mensaje OK]: imprime el resultado y sale con código != 0 si hubo fallos
terminar() {
    [ "$fallos" -eq 0 ] || { echo "$fallos fallo(s)"; exit 1; }
    echo "${1:-OK}"
}
