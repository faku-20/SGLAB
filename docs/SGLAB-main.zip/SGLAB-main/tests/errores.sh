#!/usr/bin/env bash
# Errores de base de datos: detiene MySQL unos segundos y verifica que la app responda
# un error genérico, sin SQLSTATE ni rutas (con APP_ENV=desarrollo incluye 'detalle').
# Uso: bash tests/errores.sh [BASE_URL]
source "$(dirname "$0")/lib.sh"
cd "$(dirname "$0")/.." || exit 1

trap 'rm -f "$COOKIES"; docker compose start db >/dev/null 2>&1; docker compose up -d --wait >/dev/null 2>&1' EXIT
docker compose stop db >/dev/null 2>&1

check_json POST /Controllers/loginController.php 'action=login&username=docente1&password=password' \
    '.success == false and .message == "Error interno del servidor" and (tostring | test("SQLSTATE") | not) and (.detalle | length > 0 and . != "No se pudo conectar a la base de datos")' 500

terminar "errores OK"
