<?php
require_once __DIR__ . '/../Core/acceso.php';
requerirRolApi([ROL_ADMIN, ROL_DOCENTE]);

require_once __DIR__ . '/../Models/LaboratorioDocente.php';

header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');


try {
    $laboratorios = new LaboratorioDocente('docente');

    switch ($_GET['action'] ?? '') {
        case 'obtenerEstadisticas':
            responderJson(200, ['success' => true, 'data' => $laboratorios->obtenerEstadisticas()]);

        case 'obtenerLaboratoriosConEquipos':
            responderJson(200, ['success' => true, 'data' => $laboratorios->obtenerLaboratoriosConEquipos()]);

        case 'actualizarComentario':
            $datos = json_decode(file_get_contents('php://input'), true) ?? [];
            $idLaboratorio = $datos['idLaboratorio'] ?? null;
            if (!is_numeric($idLaboratorio)) {
                responderJson(400, ['success' => false, 'message' => 'idLaboratorio inválido']);
            }
            $ok = $laboratorios->actualizarComentario((int) $idLaboratorio, trim($datos['comentario'] ?? ''));
            responderJson(200, [
                'success' => $ok,
                'message' => $ok ? 'Comentario actualizado' : 'No se pudo actualizar el comentario'
            ]);

        default:
            responderJson(400, ['success' => false, 'message' => 'Acción no válida']);
    }
} catch (Throwable $e) {
    error_log('DocenteController: ' . $e->getMessage());
    responderExcepcion($e);
}
