<?php
/**
 * Respuestas JSON comunes a todos los controladores.
 */
require_once __DIR__ . '/entorno.php';

/** Envía $datos como JSON con el código HTTP indicado y termina la ejecución. */
function responderJson(int $codigo, array $datos): never {
    http_response_code($codigo);
    header('Content-Type: application/json');
    echo json_encode($datos);
    exit;
}

/**
 * Responde un error a partir de una excepción.
 * - Errores de base de datos (PDOException) y errores de PHP (Error): mensaje genérico; el detalle va al log
 *   (y al campo 'detalle' solo en desarrollo).
 * - Otras excepciones: son mensajes propios del código ("Campo requerido: ..."), se devuelven tal cual.
 * 'error' repite 'message' porque parte del JS lee una clave y parte la otra.
 */
function responderExcepcion(Throwable $e): never {
    // Errores de base de datos y errores de programación de PHP (TypeError, Error...) no se
    // muestran: pueden incluir SQL, rutas o detalles internos
    if ($e instanceof PDOException || $e instanceof Error) {
        error_log('Error interno: ' . $e->getMessage());
        $mensaje = 'Error interno del servidor';
        // En desarrollo, el mensaje original del driver (sin el código SQLSTATE) ayuda a depurar
        $original = $e->getPrevious() ?? $e;
        $detalle = trim(preg_replace('/SQLSTATE\[[^\]]*\]\s*(\[\d+\])?\s*/', '', $original->getMessage()));
        $extra = ES_DESARROLLO ? ['detalle' => $detalle] : [];
        responderJson(500, ['success' => false, 'message' => $mensaje, 'error' => $mensaje] + $extra);
    }
    $mensaje = $e->getMessage();
    responderJson(400, ['success' => false, 'message' => $mensaje, 'error' => $mensaje]);
}
