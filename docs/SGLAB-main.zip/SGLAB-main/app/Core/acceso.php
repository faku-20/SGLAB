<?php
/**
 * Control de acceso por rol. Cada vista o controlador protegido llama, en su primera línea,
 * a requerirRolVista([...]) o requerirRolApi([...]) con los roles que pueden usarlo.
 */
require_once __DIR__ . '/entorno.php';
require_once __DIR__ . '/respuestas.php';

const ROL_ADMIN = 1;
const ROL_DOCENTE = 2;
const ROL_ESTUDIANTE = 3;

/** Rol del usuario logueado, o null si no hay sesión. */
function rolActual(): ?int {
    if (!isset($_SESSION['usuario_id'], $_SESSION['idTipoUsuario'])) {
        return null;
    }
    return (int) $_SESSION['idTipoUsuario'];
}

/** Para vistas: sin sesión o con otro rol, redirige al login. */
function requerirRolVista(array $roles): void {
    if (!in_array(rolActual(), $roles, true)) {
        header('Location: login_usuario.html');
        exit;
    }
}

/** Para controladores JSON: 401 sin sesión, 403 con un rol no permitido. */
function requerirRolApi(array $roles): void {
    $rol = rolActual();
    if ($rol === null) {
        responderJson(401, ['success' => false, 'message' => 'No autenticado', 'error' => 'No autenticado']);
    }
    if (!in_array($rol, $roles, true)) {
        responderJson(403, ['success' => false, 'message' => 'No autorizado', 'error' => 'No autorizado']);
    }
}
