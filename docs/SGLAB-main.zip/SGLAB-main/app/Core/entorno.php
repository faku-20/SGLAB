<?php
/**
 * Entorno de la aplicación: primer require de todo punto de entrada.
 * - Carga dependencias (vendor/) y variables del .env de la raíz.
 * - Muestra errores PHP solo si APP_ENV=desarrollo (el resto los oculta y los loguea).
 * - Inicia la sesión con una cookie httponly y SameSite=Lax.
 */
require_once __DIR__ . '/../../vendor/autoload.php';

Dotenv\Dotenv::createImmutable(__DIR__ . '/../../')->safeLoad();

/** Lee una variable de entorno (del .env o de Docker); '' si no existe. */
function variableEntorno(string $nombre): string {
    $valor = $_ENV[$nombre] ?? $_SERVER[$nombre] ?? getenv($nombre);
    return $valor === false ? '' : (string) $valor;
}

define('ES_DESARROLLO', variableEntorno('APP_ENV') === 'desarrollo');

error_reporting(E_ALL);
ini_set('log_errors', '1');
ini_set('display_errors', ES_DESARROLLO ? '1' : '0');
ini_set('display_startup_errors', ES_DESARROLLO ? '1' : '0');

if (PHP_SAPI !== 'cli' && session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}
