# 🏫 Sistema de Gestión de Laboratorios ITI-UTU

Sistema web para la gestión de laboratorios de computación, equipos y registros de estado.

## 📋 Tabla de Contenidos

- [Características](#características)
- [Tecnologías](#tecnologías)
- [Requisitos Previos](#requisitos-previos)
- [Instalación con Docker](#instalación-con-docker)
- [Instalación con XAMPP](#instalación-con-xampp)
- [Configuración](#configuración)
- [Seguridad](#seguridad)
- [Uso](#uso)
- [Estructura del Proyecto](#estructura-del-proyecto)
- [Contribuir](#contribuir)

---

## ✨ Características

- 🔐 **Autenticación multi-rol**: Administrador, Docente, Estudiante
- 🔑 **2FA (TOTP)**: Autenticación de dos factores para administradores
- 🐙 **GitHub OAuth**: Login para estudiantes con GitHub
- 📊 **Gestión de laboratorios**: Vista completa de equipos y registros
- 💬 **Comentarios**: Los docentes pueden comentar sobre el estado de los laboratorios
- 📈 **Reportes**: Registro de estado de equipos
- 🔒 **Seguridad**: control de acceso por rol, PDO prepared statements, bcrypt, 2FA, cookies de sesión SameSite (ver [Seguridad](#seguridad))

---

## 🛠️ Tecnologías

- **Backend**: PHP 8.3
- **Base de Datos**: MySQL 8.0
- **Frontend**: HTML5, CSS3, JavaScript (jQuery)
- **Framework CSS**: Bootstrap 5
- **Autenticación**: TOTP (Google Authenticator), GitHub OAuth
- **Containerización**: Docker & Docker Compose

---

## 📦 Requisitos Previos

### Para Docker (Recomendado):
- [Docker Desktop](https://www.docker.com/products/docker-desktop) instalado
- [Git](https://git-scm.com/) instalado

### Para XAMPP (Desarrollo local):
- [XAMPP](https://www.apachefriends.org/) con PHP 8.3+
- [Composer](https://getcomposer.org/) instalado
- MySQL/MariaDB

---

## 🐳 Instalación con Docker (Recomendado)

### 1. Clonar el repositorio

```bash
git clone git@github.com:UTU-ITI/SGLAB.git
cd SGLAB
```

### 2. Levantar todo

```bash
./start-docker.sh          # Linux/macOS (Windows: start-docker.bat)
```

El script crea `.env` a partir de `.env.example` si no existe y ejecuta `docker compose up -d --build`. A mano es lo mismo:

```bash
cp .env.example .env
docker compose up -d --build
```

En el primer arranque el contenedor `web` instala las dependencias de Composer (`vendor/`) y MySQL carga `database/01-schema.sql` y crea los usuarios por rol con `database/02-init-users.sh`.

### 3. Acceder a la aplicación

- **Aplicación web**: http://localhost:8080
- **phpMyAdmin**: http://localhost:8081 (usuario `root`, contraseña `MYSQL_ROOT_PASSWORD` de `.env`)

MySQL no publica el puerto 3306 en el host (para no chocar con un MySQL local); se accede por phpMyAdmin o con `docker compose exec db mysql ...`.

### 4. Usuarios de prueba

| Rol | Usuario | Contraseña | Características |
|-----|---------|------------|----------------|
| **Administrador** | `sysadmin` | `password` | 2FA obligatorio (Google Authenticator) |
| **Docente** | `docente1` | `password` | Acceso a gestión de laboratorios |
| **Estudiante** | - | - | Login con GitHub OAuth |

### 5. Verificar que todo funciona

```bash
bash tests/estructura.sh   # estructura del repo
bash tests/smoke.sh        # pruebas HTTP contra http://localhost:8080
bash tests/seguridad.sh    # control de acceso y login (ver "Seguridad")
```

---

## 📂 Comandos Docker Útiles

```bash
docker compose up -d --build     # levantar (reconstruyendo la imagen)
docker compose down              # detener
docker compose ps                # estado de los servicios
docker compose logs -f web       # logs de Apache/PHP
docker compose logs -f db        # logs de MySQL
docker compose exec web bash     # entrar al contenedor web
docker compose exec web composer install
docker compose exec db sh -c 'mysql -uroot -p"$MYSQL_ROOT_PASSWORD" bddsglab6'
```

### Reiniciar la base de datos

Los scripts de `database/` se ejecutan **solo cuando el volumen de MySQL está vacío**. Si cambiás el esquema o la base quedó con datos viejos:

```bash
docker compose down -v           # CUIDADO: borra todos los datos de la base
docker compose up -d --build
```

---

## 💻 Instalación con XAMPP (Alternativa)

1. Clonar el repositorio y ejecutar `composer install` en la raíz.
2. Configurar el DocumentRoot de Apache (o un VirtualHost) apuntando a la carpeta **`public/`** del repo. Solo esa carpeta debe ser accesible por web.
3. En phpMyAdmin importar `database/01-schema.sql` y crear los usuarios de `database/02-init-users.sh` (más `sgapp_admin`).
4. `cp .env.example .env` y cambiar `DB_HOST=localhost`.
5. Acceder a la URL del VirtualHost (por ejemplo http://localhost/).

---

## ⚙️ Configuración

### Archivo `.env`

La plantilla completa está en `.env.example`. Las variables principales:

```env
MYSQL_ROOT_PASSWORD=...        # contenedor MySQL
MYSQL_DATABASE=bddsglab6
DB_HOST=db                     # "db" para Docker, "localhost" para XAMPP
DB_NAME=bddsglab6
DB_USER_LOGIN=... DB_USER_DOCENTE=... DB_USER_ESTUDIANTE=... DB_USER_ADMIN=...
GITHUB_CLIENT_ID=tu_client_id
GITHUB_CLIENT_SECRET=tu_client_secret
GITHUB_REDIRECT_URI=http://localhost:8080/Controllers/githubAuthController.php
```

### GitHub OAuth

1. Ir a https://github.com/settings/developers
2. Click en "New OAuth App"
3. Configurar:
   - **Application name**: Sistema Gestión Laboratorios
   - **Homepage URL**: `http://localhost:8080`
   - **Callback URL**: `http://localhost:8080/Controllers/githubAuthController.php`
4. Copiar Client ID y Client Secret a `.env`

---

## 🔒 Seguridad

### Roles y acceso

| Rol | Pantallas | Login |
|-----|-----------|-------|
| **Administrador** | Menú admin, equipos, usuarios y también el panel docente | Usuario + contraseña + código 2FA |
| **Docente** | Menú docente y panel de laboratorios | Usuario + contraseña |
| **Estudiante** | Menú estudiante (reportar el estado de un equipo) | GitHub |

Cada vista y controlador declara en su primera línea qué roles lo pueden usar (`app/Core/acceso.php`):

```php
requerirRolVista([ROL_ADMIN, ROL_DOCENTE]);   // vistas: si no corresponde, vuelve al login
requerirRolApi([ROL_ADMIN]);                  // controladores JSON: 401 sin sesión, 403 con otro rol
```

### `APP_ENV`

- `desarrollo`: los errores de PHP se ven en pantalla y los errores de base de datos traen un campo `detalle` en el JSON.
- `produccion` (o sin definir): los errores solo van al log (`docker compose logs web`). **Usar este valor en el servidor del laboratorio.**

### `API_KEY`

Los scripts que envían reportes de equipos (`api/api_registro.php`) se autentican con el header `X-API-KEY`. La clave se define en `.env`:

```bash
openssl rand -hex 32     # copiar el resultado en API_KEY=... del .env
```

La clave que antes estaba escrita en el código quedó en el historial de git: es pública y no se debe reutilizar. `scripts/linux/procesar_reportes.sh` la toma del entorno: `API_KEY=... ./procesar_reportes.sh`.

### Login con GitHub (prueba manual)

El login de estudiantes no se puede probar automáticamente. Para probarlo: crear una OAuth App (ver "GitHub OAuth"), cargar `GITHUB_CLIENT_ID`/`GITHUB_CLIENT_SECRET` en `.env`, reiniciar (`docker compose up -d --force-recreate web`) y entrar con una cuenta de GitHub cuyo email coincida con un estudiante (`juan.perez@estudiante.edu.uy`, por ejemplo).

### Tests de seguridad

```bash
bash tests/seguridad.sh   # acceso por rol, login (2FA, OAuth, sesión), clave API, CORS
bash tests/errores.sh     # detiene la base unos segundos y verifica que no se filtren errores SQL
```

---

## 🚀 Uso

### Login

#### Administrador
1. Acceder a http://localhost:8080
2. Ingresar usuario y contraseña
3. **Primera vez**: Escanear código QR con Google Authenticator
4. Ingresar código de 6 dígitos

#### Docente
1. Acceder a http://localhost:8080
2. Ingresar usuario y contraseña
3. Acceso directo al panel docente

#### Estudiante
1. Acceder a http://localhost:8080
2. Click en "Continuar con GitHub"
3. Autorizar aplicación en GitHub
4. **Importante**: El email de GitHub debe coincidir con el email registrado en el sistema

### Panel Docente - Gestión de Laboratorios

1. Login como docente
2. Ir a "Laboratorios"
3. Ver todos los laboratorios con sus equipos
4. Ver último registro de cada equipo
5. Agregar comentarios sobre el estado de cada laboratorio

---

## 📁 Estructura del Proyecto

```
SGLAB/
├── app/                       # Lógica de la aplicación (NO accesible por web)
│   ├── Core/                  # entorno (.env, APP_ENV, sesión), respuestas JSON, control de acceso
│   ├── Models/                # Modelos: Database, Usuario, Equipo, Auth, ...
│   ├── Controllers/           # Controladores: login, Docente, Equipo, logout, ...
│   ├── views/                 # Vistas PHP: menús por rol, equipos, usuarios
│   └── api/                   # api_registro.php (registro de equipos)
├── public/                    # DocumentRoot de Apache (lo único accesible por web)
│   ├── index.html             # Página de entrada
│   ├── Controllers/*.php      # Puentes de una línea → app/Controllers
│   ├── views/                 # login_usuario.html + puentes → app/views
│   ├── api/                   # Puente → app/api
│   └── assets/{css,js,img}    # Recursos estáticos
├── database/
│   ├── 01-schema.sql          # Esquema y datos de prueba
│   └── 02-init-users.sh       # Usuarios MySQL por rol
├── docker/php/
│   ├── Dockerfile             # Imagen PHP 8.3 + Apache
│   ├── docker-entrypoint.sh   # Instala vendor/ si falta y lanza Apache
│   └── php.ini
├── scripts/
│   ├── linux/                 # Backups, provisión, reportes
│   └── windows/               # Scripts PowerShell de registro de equipos
├── tests/                     # estructura.sh y smoke.sh
├── doc/                       # Diagramas UML, requerimientos, guías
├── docker-compose.yaml
├── composer.json / composer.lock
├── .env.example               # Plantilla de configuración (.env no va a Git)
├── start-docker.sh / .bat
└── README.md
```

**¿Por qué los "puentes"?** Las URLs que usa el JavaScript (`../Controllers/loginController.php`, etc.) siguen siendo las mismas, pero el código real vive en `app/`, fuera del docroot. Así nadie puede pedir por el navegador `Models/Database.php`, `.env` o `vendor/`. Un puente es una sola línea:

```php
<?php require __DIR__ . '/../../app/Controllers/loginController.php';
```

---

## 🐛 Solución de Problemas

### Error de conexión a base de datos en Docker

```bash
docker compose ps          # ¿db está "healthy"?
docker compose logs db     # errores de MySQL o de los scripts de database/
```

Si cambiaste credenciales en `.env` después del primer arranque, los usuarios de MySQL no se actualizan solos: reiniciá la base (ver "Reiniciar la base de datos").

### Composer no encuentra dependencias

```bash
docker compose exec web composer install
```

### GitHub OAuth no funciona

1. Verificar que las URLs en GitHub OAuth App coincidan exactamente
2. Verificar que `GITHUB_REDIRECT_URI` en `.env` sea correcta
3. Revisar logs: `docker compose logs -f web`

---

## 🤝 Contribuir

1. Fork el proyecto
2. Crear una rama: `git checkout -b feature/nueva-funcionalidad`
3. Commit cambios: `git commit -am 'Agregar nueva funcionalidad'`
4. Push a la rama: `git push origin feature/nueva-funcionalidad`
5. Crear Pull Request

---

## 📝 Notas Importantes

### Sobre vendor/ y Git

⚠️ **vendor/ NO se sube a Git**

La carpeta `vendor/` contiene las dependencias de Composer y NO debe subirse al repositorio.

**¿Por qué?**
- Es pesada (muchos archivos)
- Se puede regenerar con `composer install`
- Puede causar conflictos entre sistemas

**¿Cómo se instala?**
- **Con Docker**: Automáticamente en el primer arranque (`docker/php/docker-entrypoint.sh`)
- **Con XAMPP**: Ejecutar `composer install` manualmente

### Sobre .env y Git

⚠️ **.env NO se sube a Git** (contiene credenciales sensibles)

- Usa `.env.example` como plantilla
- Cada desarrollador crea su propio `.env`

---

## 📄 Licencia

Este proyecto es de código abierto para fines educativos.

---

## 👥 Autores

- **Equipo de Desarrollo** - ITI-UTU

---

## 🙏 Agradecimientos

- Instituto Tecnológico Industrial (ITI)
- Universidad del Trabajo del Uruguay (UTU)
- Comunidad de código abierto

---

**¿Preguntas o problemas?** Abre un [Issue](https://github.com/UTU-ITI/SGLAB/issues)
