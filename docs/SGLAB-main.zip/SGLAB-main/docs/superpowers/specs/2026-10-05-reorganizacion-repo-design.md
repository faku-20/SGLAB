# Reorganización del repo SGLAB y entrypoint funcional

Fecha: 2026-10-05
Estado: aprobado en conversación, pendiente de revisión escrita

## Objetivo

- Una sola versión canónica de la app, sin carpetas ni archivos colgados.
- `docker compose up --build` desde la raíz levanta web + base de datos sin errores.
- El entrypoint de Docker (`docker-entrypoint.sh`) existe y funciona.
- La página de entrada (`/`) carga y lleva a un login funcional; los paneles por rol no dan 404.

## Contexto (situación actual)

- `public/` ("PHP-simple") es la versión funcional más completa, pero todo está dentro del docroot (Models, Controllers, `vendor/`, `.env`, SQL, Dockerfile propio).
- `app/` es un esqueleto MVC no funcional (contiene vistas Blade de Laravel mal ubicadas, namespaces inexistentes). Solo se rescata la *idea* de la estructura.
- `assets/` + `src/` son una versión anterior.
- Hay 4 docker-compose, 2 Dockerfiles y 6 SQL distintos.
- `docker/php/Dockerfile` declara `ENTRYPOINT ["docker-entrypoint.sh"]` pero el script no existe, y su `COPY ./config/php.ini` tiene ruta incorrecta.
- Bugs que rompen la ejecución en Linux:
  - `public/Models/Database.php:2` → `__DIR__ . '../../vendor/autoload.php'` (falta `/`).
  - `loginController.php` y `githubAuthController.php` requieren `../Models/Auth.php`; el archivo es `auth.php`.
  - `api/api_registro.php` requiere `../models/...` (minúscula).
  - Varios `require_once 'Database.php'` / `'../Models/...'` relativos al directorio de trabajo.
- Referencias a controladores inexistentes:
  - `Controllers/logoutController.php` (todas las vistas con menú).
  - `Controllers/DocenteController.php` (`Public/js/panel_docente_laboratorios.js`).
- `sql/BaseDatos.sql` y `public/BaseDatos.sql` son idénticos salvo finales de línea.

## Decisiones

1. **Fusionar**: estructura MVC con el código funcional de `public/`.
2. **Docroot separado**: la lógica vive en `app/` fuera del docroot; `public/` solo expone la entrada, assets y archivos puente.
3. **Puentes de una línea** en `public/` con las mismas rutas que hoy, para no reescribir las URLs del JS ni los redirects.
4. **Lo descartado se borra**; queda en git bajo el tag `pre-reorganizacion`.
5. **Dockerfile base**: `docker/php/Dockerfile` (conserva los comentarios didácticos), corregido.

## Estructura final

```
SGLAB/
├── app/
│   ├── Models/                # ← public/Models (auth.php → Auth.php)
│   ├── Controllers/           # ← public/Controllers + logoutController.php + DocenteController.php
│   ├── api/                   # ← public/api/api_registro.php
│   └── views/                 # ← public/views
├── public/                    # DocumentRoot de Apache
│   ├── index.html
│   ├── Controllers/*.php      # puentes → app/Controllers
│   ├── views/*.php            # puentes → app/views
│   ├── views/login_usuario.html  # estático, se mueve tal cual (no es PHP)
│   ├── api/api_registro.php   # puente → app/api
│   └── assets/{css,js,img}    # ← public/Public
├── database/
│   ├── 01-schema.sql          # ← sql/BaseDatos.sql
│   └── 02-init-users.sh       # ← docker/init-db.sh
├── docker/php/
│   ├── Dockerfile
│   ├── docker-entrypoint.sh   # nuevo
│   └── php.ini                # ← docker/php/config/php.ini
├── scripts/
│   ├── linux/                 # ← sh/ + public/api/procesar_reportes.sh
│   └── windows/               # ← ps/ ; LAB6/*.toml → scripts/windows/ejemplos/
├── doc/                       # sin cambios + DOCKER_QUICK_START.md
├── composer.json, composer.lock
├── docker-compose.yaml
├── .env.example
├── .gitignore
├── start-docker.sh, start-docker.bat
└── README.md
```

### Formato de un puente

```php
<?php require __DIR__ . '/../../app/Controllers/loginController.php';
```

Las vistas puente funcionan igual (`public/views/menu_admin.php` → `app/views/menu_admin.php`). Como la URL del navegador no cambia, las rutas relativas del HTML (`../assets/css/...`, `../Controllers/...`) siguen resolviendo bien.

### Assets

`public/Public/` se renombra a `public/assets/`. Se actualizan todas las referencias `Public/` / `../Public/` en `index.html`, vistas y JS.

## Qué se borra

`app/` actual, `assets/`, `src/`, `sql/` (tras mover BaseDatos.sql), `docker/init-db.sh` y `docker/php.ini` sueltos (tras mover), `docker/php/config/`, `public/vendor/`, `public/composer.phar`, `public/composer.json`/`composer.lock` (se usa el de la raíz, actualizado), `public/estructura.txt`, `public/docker/`, `public/docker-compose.yml`, `public/Dockerfile`, `public/BaseDatos.sql`, `public/.env.example`, `public/Controllers/php_errors.log`, `docker-compose2.yaml`, `docker-compose copia.yaml`, `sglab.sql`, `SqlQuery_1.sql`, `env.example`, `test_session.php`, `test_session_read.php`, `DOCKER_QUICK_START.md` de la raíz (duplicado en `doc/`), todos los `.DS_Store`, `LAB6/` (tras mover), `sh/`, `ps/` (tras mover).

`.gitignore` agrega: `vendor/`, `*.log`, `.DS_Store`, `composer.phar`.

## Composer

`composer.json` de la raíz se actualiza con las dependencias reales que usa `public/composer.json` (phpdotenv, librería TOTP, etc.); se elimina el `autoload psr-4 App\\ → src/` (no hay clases con namespace). `vendor/` en la raíz, ignorado por git.

## Docker

### Dockerfile (`docker/php/Dockerfile`)

- `FROM php:8.3-apache`, TZ America/Montevideo.
- Extensiones: `pdo_mysql`, `mbstring`, `intl`, `zip`, `gd` (las que instala hoy `public/Dockerfile`).
- `a2enmod rewrite headers`.
- `ENV APACHE_DOCUMENT_ROOT=/var/www/sglab/public` + `sed` estándar sobre `sites-available/*.conf` y `apache2.conf`.
- `COPY --from=composer:latest /usr/bin/composer /usr/bin/composer`.
- `COPY docker/php/php.ini` y `COPY docker/php/docker-entrypoint.sh` (build context = raíz).
- `WORKDIR /var/www/sglab`, `ENTRYPOINT ["docker-entrypoint.sh"]`, `CMD ["apache2-foreground"]`.

### docker-entrypoint.sh

```sh
#!/bin/sh
set -e
cd /var/www/sglab
if [ ! -f vendor/autoload.php ]; then
    composer install --no-interaction --no-dev --optimize-autoloader
fi
mkdir -p /var/log/sglab && chown www-data:www-data /var/log/sglab
exec "$@"
```

Debe tener finales de línea LF (se agrega `.gitattributes` con `*.sh text eol=lf` para que no lo rompa un checkout en Windows).

### docker-compose.yaml

- `web`: `build: {context: ., dockerfile: docker/php/Dockerfile}`, volumen `.:/var/www/sglab`, `env_file: .env`, puertos `8080:80`, `depends_on: db: condition: service_healthy`.
- `db`: `mysql:8.0`, `env_file: .env`, volumen nombrado de datos + `./database:/docker-entrypoint-initdb.d`, healthcheck con `mysqladmin ping`.
- `phpmyadmin`: puerto `8081`, `PMA_HOST=db`.
- Sin credenciales escritas en el compose.

### .env.example

```
# MySQL (contenedor)
MYSQL_ROOT_PASSWORD=root_password_123
MYSQL_DATABASE=bddsglab6

# App
DB_HOST=db
DB_NAME=bddsglab6
DB_USER_LOGIN=sgapp_login        DB_PASSWORD_LOGIN=...
DB_USER_ESTUDIANTE=...           DB_PASSWORD_ESTUDIANTE=...
DB_USER_DOCENTE=...              DB_PASSWORD_DOCENTE=...
DB_USER_ADMIN=...                DB_PASSWORD_ADMIN=...
DB_USER_BACKUP=...               DB_PASSWORD_BACKUP=...

# GitHub OAuth
GITHUB_CLIENT_ID=
GITHUB_CLIENT_SECRET=
GITHUB_REDIRECT_URI=http://localhost:8080/Controllers/githubAuthController.php
```

Los valores de usuarios/contraseñas coinciden con los que crea `database/02-init-users.sh` (se mantienen los actuales de `public/.env.example`). `02-init-users.sh` no cambia de contenido (sigue usando `bddsglab6` y las contraseñas fijas); solo se mueve.

`start-docker.sh` / `.bat`: ya copian `.env` desde una plantilla; se ajusta el nombre buscado a `.env.example`.

## Cambios de código

1. **Requires con `__DIR__`** en todos los Models, Controllers y `api_registro.php` (`require_once __DIR__ . '/Database.php'`, `__DIR__ . '/../Models/Usuario.php'`), con el casing real de los archivos.
2. **`Database.php`**: autoload `__DIR__ . '/../../vendor/autoload.php'`; `Dotenv::createImmutable(__DIR__ . '/../../')->safeLoad()` (la raíz del repo); `required([...])` se mantiene. Con Docker las variables llegan por `env_file`; en XAMPP vienen del `.env`.
3. **`auth.php` → `Auth.php`**.
4. **`logoutController.php`** (nuevo): `session_start()`, vaciar `$_SESSION`, borrar cookie de sesión, `session_destroy()`, `header('Location: ../index.html')`.
5. **`DocenteController.php`** (nuevo), mismo patrón que `RegistroController.php`:
   - Responde JSON.
   - Exige `$_SESSION['usuario_id']` y `$_SESSION['idTipoUsuario'] == 2` (docente, mismo criterio que `views/menu_docente.php`); si no, 401 JSON.
   - `?action=obtenerEstadisticas` → `LaboratorioDocente::obtenerEstadisticas()`.
   - `?action=obtenerLaboratoriosConEquipos` → `obtenerLaboratoriosConEquipos()`.
   - `?action=actualizarComentario` (POST JSON `{idLaboratorio, comentario}`) → `actualizarComentario()`.
   - Acción desconocida → 400 JSON.
   - El formato exacto de la respuesta se toma de lo que espera `panel_docente_laboratorios.js`.
6. Referencias `Public/` → `assets/`.

## Errores y casos borde

- Sin `.env` y sin variables de entorno: `required()` lanza excepción; `Database.php` ya la captura y la loguea; la página de login muestra el error genérico existente.
- DB todavía inicializando: `depends_on: service_healthy` evita que `web` arranque antes.
- `vendor/` ausente en el host: el entrypoint lo instala en el primer arranque.
- Volumen `db` ya existente con un esquema viejo: los scripts de `database/` no se re-ejecutan; se documenta `docker compose down -v` en el README.

## Verificación (criterios de aceptación)

1. `php -l` sin errores en todos los `.php` de `app/` y `public/` (se ejecuta dentro del contenedor `web`; no hay PHP en el host).
2. `grep` sin referencias a `Public/`, `models/`, `Auth.php` mal escrito ni rutas a archivos borrados.
3. `docker compose down -v && docker compose up --build -d` termina con los tres servicios `healthy`/`running`; `docker compose logs web` sin errores del entrypoint.
4. `curl -I localhost:8080/` → 200; `/views/login_usuario.html` → 200; `/assets/css/estilos.css` → 200.
5. `curl -I localhost:8080/Models/Database.php` → 404 (lógica no expuesta).
6. `POST /Controllers/loginController.php` con `docente1` / `password` (el hash del seed es el bcrypt conocido de "password"; se confirma con `password_verify` en el contenedor) → JSON de éxito (no fatal error).
7. Login `docente1` en el navegador → panel docente carga estadísticas y laboratorios sin 404 en consola; logout vuelve a `/`.
8. README actualizado con la estructura nueva y los pasos de arranque.

## Fuera de alcance

- Router/front controller, namespaces o autoload PSR-4.
- Cambios de esquema de base de datos.
- Refactors o mejoras de seguridad del código existente más allá de lo necesario para que ejecute.
- Configurar una app OAuth de GitHub real.
