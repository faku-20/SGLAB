# Seguridad y control de acceso de SGLAB

Fecha: 2026-10-06
Estado: aprobado en conversación, pendiente de revisión escrita
Antecedente: `2026-10-05-reorganizacion-repo-design.md` (estructura `app/` + `public/`)

## Objetivo

Cada pantalla y cada endpoint responde solo al rol que corresponde, los secretos salen del código, los errores no filtran detalles internos y los tres flujos de login quedan protegidos contra los ataques conocidos que hoy los afectan. Sin frameworks: PHP simple y legible (proyecto educativo). Los flujos que hoy funcionan siguen funcionando (`tests/estructura.sh` y `tests/smoke.sh` en verde).

## Situación actual (problemas)

| # | Problema | Dónde |
|---|---|---|
| 1 | Sin control de sesión: alta/baja/edición de equipos anónima | `EquipoController` (todas las acciones) |
| 2 | Lecturas de admin sin sesión | `RegistroController` (todo salvo `crearReporte`) |
| 3 | Solo verifican sesión, no rol: un docente usa pantallas y APIs de admin | `usuariosController`, vistas `menu_admin`, `equipos`, `usuarios`, `menu_estudiante` |
| 4 | Clave API escrita en el código y commiteada | `app/api/api_registro.php:8`, `scripts/linux/procesar_reportes.sh:6` |
| 5 | `display_errors=On` fijo y `getMessage()` de errores de BD al cliente (SQLSTATE, rutas) | `docker/php/php.ini`, `Database.php`, `catch` de controladores |
| 6 | OAuth: `state` se genera pero no se guarda ni se compara (CSRF de login) | `githubAuthController.php` |
| 7 | 2FA: `verify_2fa`/`setup_2fa` toman `user_id` del POST: con un código TOTP válido se saltea la contraseña | `loginController.php` |
| 8 | Sin `session_regenerate_id` al loguear (fijación de sesión) | `crearSesion`, `crearSesionEstudiante` |
| 9 | `Access-Control-Allow-Origin: *` | `loginController`, `EquipoController`, `RegistroController`, `usuariosController` |
| 10 | Secretos y sesión completa en el log | `loginController` (secret TOTP, QR), vistas docente (`$_SESSION`) |

## Decisiones

1. **Helper compartido** (`app/Core/acceso.php`) llamado en la primera línea de cada vista/controlador; no controles en los puentes ni copias del mismo `if`.
2. **Admin accede a todo** lo de admin y al panel docente; docente y estudiante, solo lo suyo.
3. **Errores según `APP_ENV`**: `desarrollo` muestra errores; cualquier otro valor (o ausente) los oculta. Los JSON nunca devuelven SQLSTATE; en desarrollo agregan un campo `detalle`.
4. Acciones de `RegistroController` no listadas en su mapa de permisos → solo admin (cerrado por defecto).

## Componentes nuevos

### `app/Core/entorno.php`

Primer `require` de todo punto de entrada (directo o vía `acceso.php`).

- `require_once` de `vendor/autoload.php`; `Dotenv::createImmutable(<raíz>)->safeLoad()`.
- `APP_ENV === 'desarrollo'` → `ini_set('display_errors', '1')`; si no → `'0'`. `log_errors` siempre `1`. `error_reporting(E_ALL)`.
- Si no hay sesión activa: `session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'path' => '/'])` y `session_start()`.
- Constante `ES_DESARROLLO` (bool) para el resto del código.

### `app/Core/respuestas.php`

- `responderJson(int $codigo, array $datos): never` — `http_response_code`, `Content-Type: application/json`, `echo json_encode`, `exit`.
- `responderExcepcion(Throwable $e): never`:
  - `PDOException` → `error_log` del detalle; `responderJson(500, ['success' => false, 'message' => 'Error interno del servidor'] + (ES_DESARROLLO ? ['detalle' => $e->getMessage()] : []))`.
  - Otra `Throwable` → `responderJson(400, ['success' => false, 'message' => $e->getMessage()])` (son mensajes propios: "Campo requerido: hostname", "Método no permitido").
  - Para conservar la clave que hoy usa el JS, el JSON incluye `error` con el mismo texto que `message` (los controladores de equipos, registros y usuarios responden `error`; el resto `message`).

### `app/Core/acceso.php`

`require_once` de `entorno.php` y `respuestas.php`.

- Constantes `ROL_ADMIN = 1`, `ROL_DOCENTE = 2`, `ROL_ESTUDIANTE = 3`.
- `rolActual(): ?int` — `$_SESSION['idTipoUsuario']` si existe `usuario_id`, si no `null`.
- `requerirRolVista(array $roles): void` — si `rolActual()` no está en `$roles` → `header('Location: login_usuario.html')` y `exit`.
- `requerirRolApi(array $roles): void` — sin sesión → `responderJson(401, [... 'message' => 'No autenticado'])`; rol no permitido → `responderJson(403, [... 'message' => 'No autorizado'])`.

## Matriz de acceso

| Archivo | Roles | Llamada |
|---|---|---|
| `views/menu_admin.php`, `views/equipos.php`, `views/usuarios.php` | admin | `requerirRolVista([ROL_ADMIN])` |
| `views/menu_docente.php`, `views/panel_docente_laboratorios.php` | admin, docente | `requerirRolVista([ROL_ADMIN, ROL_DOCENTE])` |
| `views/menu_estudiante.php` | estudiante | `requerirRolVista([ROL_ESTUDIANTE])` |
| `Controllers/EquipoController.php`, `Controllers/usuariosController.php` | admin | `requerirRolApi([ROL_ADMIN])` |
| `Controllers/DocenteController.php` | admin, docente | `requerirRolApi([ROL_ADMIN, ROL_DOCENTE])` (reemplaza su verificación manual) |
| `Controllers/RegistroController.php` | por acción (abajo) | `requerirRolApi($permisos[$accion] ?? [ROL_ADMIN])` |
| `Controllers/loginController.php`, `githubAuthController.php`, `logoutController.php` | público | solo `entorno.php` |
| `views/error.php`, `views/vinculacion_github.php` | público | solo `entorno.php` |
| `api/api_registro.php` | clave API | ver "Clave API" |

Permisos de `RegistroController`:

```php
$permisos = [
    'obtenerEquipos' => [ROL_ADMIN, ROL_ESTUDIANTE],
    'crearReporte'   => [ROL_ESTUDIANTE],
];
// cualquier otra acción: [ROL_ADMIN]
```

Las vistas pierden su bloque de verificación actual y los `error_log` que vuelcan la sesión.

## Flujos de login

★ = nuevo o cambiado respecto de hoy.

### Docente

```mermaid
sequenceDiagram
    participant N as Navegador
    participant L as loginController
    participant A as Auth / BD
    participant V as menu_docente.php
    N->>L: POST action=login (username, password)
    L->>A: loginByUsername()
    A-->>L: Usuario tipo 2 (bcrypt ok, sin bloqueo)
    L->>L: crearSesion(): ★ session_regenerate_id(true), usuario_id, idTipoUsuario
    L-->>N: {success, redirect: menu_docente.php}
    N->>V: GET
    V->>V: ★ requerirRolVista([ADMIN, DOCENTE])
    V-->>N: 200 HTML
```

### Admin (contraseña + TOTP)

```mermaid
sequenceDiagram
    participant N as Navegador
    participant L as loginController
    participant A as Auth / BD
    N->>L: POST action=login (username, password)
    L->>A: loginByUsername()
    A-->>L: Usuario tipo 1
    L->>L: ★ $_SESSION['2fa_pendiente'] = id
    alt sin secret_2fa (primera vez)
        L->>A: guardarSecret2FATemp(id, secret)
        L-->>N: {requires_2fa, needs_setup:true, qr_code, secret}
        N->>L: POST action=setup_2fa (code)
        L->>L: ★ id = $_SESSION['2fa_pendiente'] (se ignora user_id del POST)
        L->>A: verify(code) con secret temporal → confirmarSecret2FA
    else secret configurado
        L-->>N: {requires_2fa, needs_setup:false}
        N->>L: POST action=verify_2fa (code)
        L->>L: ★ id = $_SESSION['2fa_pendiente']
        L->>A: verify(code) con secret guardado
    end
    L->>L: ★ unset 2fa_pendiente; crearSesion() (★ regenerate_id)
    L-->>N: {success, redirect: menu_admin.php}
    N->>L: GET menu_admin.php → ★ requerirRolVista([ADMIN]) → 200
```

- `setup_2fa`/`verify_2fa` sin `2fa_pendiente` en sesión → `{success:false, message:'Sesión de login expirada. Ingrese nuevamente usuario y contraseña.'}`.
- El JS puede seguir enviando `user_id`; el servidor lo ignora.
- ★ Se eliminan los `error_log` del secret y del QR.

### Estudiante (GitHub OAuth)

```mermaid
sequenceDiagram
    participant N as Navegador
    participant G as githubAuthController
    participant GH as GitHub
    participant B as BD
    N->>G: GET (sin code)
    G->>G: state = bin2hex(random_bytes(16)); ★ $_SESSION['oauth_state'] = state
    G-->>N: 302 github.com/login/oauth/authorize?state=…
    N->>GH: autoriza
    GH-->>N: 302 callback ?code&state
    N->>G: GET ?code&state
    G->>G: ★ hash_equals($_SESSION['oauth_state'], $_GET['state'])? no → error.php
    G->>G: ★ unset oauth_state
    G->>GH: POST access_token; GET /user, /user/emails
    G->>B: buscar por github_id; si no, por email de estudiante y vincular
    G->>G: crearSesionEstudiante() (★ regenerate_id)
    G-->>N: 302 menu_estudiante.php
    N->>G: GET menu_estudiante.php → ★ requerirRolVista([ESTUDIANTE]) → 200
```

- `state` ausente o distinto (o sin `oauth_state` en sesión) → `$_SESSION['error_mensaje'] = 'La solicitud de inicio de sesión no es válida o expiró. Intentá nuevamente.'` y 302 a `../views/error.php`.

## Errores y entorno

- `docker/php/php.ini`: `display_errors = Off`, `display_startup_errors = Off`. `entorno.php` los activa en desarrollo.
- `.env.example`: `APP_ENV=desarrollo` (con comentario: usar `produccion` en el servidor del laboratorio).
- `Database.php`: el mensaje de su excepción pasa a `'No se pudo conectar a la base de datos'`; el detalle PDO va a `error_log`.
- Todos los `catch` de controladores que hoy responden `$e->getMessage()` llaman a `responderExcepcion($e)`. `loginController` deja de anteponer "Error en el servidor: " al mensaje.

## Clave API

- `api_registro.php`: se elimina `define('API_SECRET_KEY', ...)`. Usa `$_ENV['API_KEY'] ?? ''`.
  - `API_KEY` vacía → 500 `'API no configurada'`.
  - `!hash_equals($clave, $_SERVER['HTTP_X_API_KEY'] ?? '')` → 401.
- `.env.example`: `API_KEY=` vacía, comentario `# Generar con: openssl rand -hex 32`.
- La clave anterior (`TU_CLAVE_SECRETA_AQUI_12345`) está en el historial de git: se considera pública y no se reutiliza.
- `scripts/linux/procesar_reportes.sh`: `API_URL="${API_URL:-http://localhost:8080/api/api_registro.php}"`, `API_KEY="${API_KEY:?Definí API_KEY (la misma que en .env)}"`.

## CORS

Se eliminan los headers `Access-Control-Allow-*` y el manejo de `OPTIONS` de `loginController`, `EquipoController`, `RegistroController`, `usuariosController`. El frontend es del mismo origen.

## Tests

- `tests/lib.sh` (nuevo): helpers `check_status`, `check_json`, `check_page`, `check_redirect` movidos desde `smoke.sh` (que pasa a `source tests/lib.sh`). `check_json` acepta un cookie jar alternativo vía variable `COOKIES`.
- `tests/seguridad.sh` (nuevo):
  - Sin sesión: vistas `menu_admin`, `equipos`, `usuarios`, `menu_estudiante` → 302 a `login_usuario.html`; `EquipoController?action=obtenerTodos`, `POST EquipoController?action=crearEquipo`, `usuariosController?action=obtenerUsuarios`, `RegistroController?action=obtenerTodosRegistros`, `RegistroController?action=obtenerEquipos` → 401 JSON.
  - Docente: mismos endpoints → 403 JSON; vistas admin y estudiante → 302 login; `DocenteController?action=obtenerEstadisticas` → 200.
  - Admin con TOTP: login `sysadmin`/`password`; secret de la respuesta (`needs_setup`) o de `Usuarios.secret_2fa` vía `docker compose exec -T db`; código con `OTPHP\TOTP::create($secret)->now()` vía `docker compose exec -T web php`. Luego: vistas admin → `check_page` 200; `EquipoController?action=obtenerTodos`, `usuariosController?action=obtenerUsuarios`, `RegistroController?action=obtenerTodosRegistros` → 200 `.success == true`; `DocenteController?action=obtenerEstadisticas` → 200; `RegistroController?action=crearReporte` → 403.
  - Bypass 2FA: cookie jar nuevo, `POST verify_2fa` con `user_id=1` y código válido, sin paso de contraseña → `.success == false`.
  - Fijación de sesión: `PHPSESSID` tras un login fallido ≠ `PHPSESSID` tras el login exitoso de docente.
  - OAuth: `githubAuthController.php?code=x&state=malo` y `?code=x` → 302 a `error.php`; siguiendo el redirect, la página contiene "no es válida o expiró".
  - Clave API: sin header → 401; header incorrecto → 401; header con `API_KEY` del `.env` y `GET` → 405; con `API_KEY` vacía (ejecutando el script en el contenedor con la variable vacía) → 500.
  - CORS: headers de `loginController` y `EquipoController` sin `Access-Control-Allow-Origin`.
  - `APP_ENV`: `docker compose exec -T -e APP_ENV=desarrollo web php -r 'require "app/Core/entorno.php"; echo ini_get("display_errors");'` → `1`; con `produccion` → `0` (o vacío).
- `tests/errores.sh` (nuevo, separado porque detiene la base): `docker compose stop db`; login docente → 500, `.message` sin "SQLSTATE", y con `APP_ENV=desarrollo` existe `.detalle`; `docker compose start db` (en `trap` para que se ejecute siempre) y espera `healthy`.
- `tests/estructura.sh` agrega:
  - todo `app/views/*.php` y `app/Controllers/*.php` contiene `requerirRolVista(` o `requerirRolApi(`, salvo `loginController.php`, `githubAuthController.php`, `logoutController.php`, `error.php`, `vinculacion_github.php`;
  - ningún archivo de `app/` contiene `Access-Control-Allow-Origin`;
  - ningún archivo del repo (fuera de `docs/`, `.git`, `tests/`) contiene `TU_CLAVE_SECRETA`;
  - ningún `error_log` en `app/` incluye `$_SESSION`, `$secret` o `$qrCode`.

### No testeable automáticamente

Camino feliz del estudiante (requiere GitHub real). Se prueban sus rechazos (`crearReporte` → 403 para docente y admin). Verificación manual con una OAuth App real, documentada en el README.

## Documentación

- README: sección "Seguridad" breve: roles y qué ve cada uno, `APP_ENV`, `API_KEY` (cómo generarla y que la vieja es pública), cómo correr `tests/seguridad.sh` y `tests/errores.sh`.
- `doc/ARQUITECTURA_MVC.md`: agregar `app/Core/` al árbol.

## Fuera de alcance

- Tokens CSRF en formularios propios (mitigado por `SameSite=Lax`).
- Rate limiting más allá del bloqueo por intentos que ya existe.
- Rotar las contraseñas de los usuarios MySQL por rol.
- Cambios de esquema de base de datos.
- HTTPS (`cookie_secure`).
