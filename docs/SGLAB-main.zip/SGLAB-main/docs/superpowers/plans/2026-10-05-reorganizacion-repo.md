# Reorganización del repo SGLAB — Plan de implementación

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Dejar una sola app canónica (lógica en `app/`, docroot en `public/`), sin carpetas colgadas, que arranque con `docker compose up --build` y cuyo entrypoint y página de entrada funcionen.

**Architecture:** El código de `public/` (PHP-simple) se mueve a `app/{Models,Controllers,views,api}`; `public/` queda con `index.html`, `assets/` y puentes de una línea con las mismas URLs que hoy, así el JS no cambia. Un único `docker-compose.yaml` en la raíz construye `docker/php/Dockerfile` con DocumentRoot en `public/` y un `docker-entrypoint.sh` que instala `vendor/` si falta.

**Tech Stack:** PHP 8.3 + Apache (imagen `php:8.3-apache`), MySQL 8.0, Composer, vlucas/phpdotenv, spomky-labs/otphp, jQuery/Bootstrap (sin cambios), Bash para pruebas de humo.

**Spec:** `docs/superpowers/specs/2026-10-05-reorganizacion-repo-design.md`

## Global Constraints

- No hay PHP en el host: todo `php -l`, `composer` y `password_verify` se ejecuta dentro del contenedor `web` (`docker compose exec web ...`).
- Usar `git mv` para todo lo que se mueve (preserva historial); `git rm` para lo que se borra.
- Antes de cualquier movimiento: `git tag pre-reorganizacion`.
- DocumentRoot: `/var/www/sglab/public`; código montado en `/var/www/sglab`.
- Puertos del host: web `8080`, phpMyAdmin `8081`. MySQL **no** publica puerto al host (evita choque con un MySQL local; se accede por phpMyAdmin).
- `.env` en la raíz, nunca commiteado; `.env.example` es la única plantilla.
- `GITHUB_REDIRECT_URI=http://localhost:8080/Controllers/githubAuthController.php`.
- Respuestas JSON de controladores: `{"success": bool, "data"?: ..., "message"?: string}` (contrato que ya usa el JS).
- Fuera de alcance: router, namespaces, cambios de esquema, refactors no necesarios para ejecutar.
- Mensajes de commit en español, terminados con `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`.

## Review Focus

1. **`docker-entrypoint.sh` con CRLF** (checkout en Windows) → el contenedor debe arrancar igual. Prueba: Task 3 verifica `file docker/php/docker-entrypoint.sh` sin "CRLF" y `.gitattributes` con `*.sh text eol=lf`.
2. **Volumen de DB viejo con esquema anterior** → la app no debe fallar en silencio; el README indica `docker compose down -v`. Prueba: Task 3 corre la smoke test tras `down -v`; Task 5 verifica la sección en README.
3. **Arranque sin `.env`** → `start-docker.sh` lo crea desde `.env.example`. Prueba: Task 3 borra `.env` y corre `./start-docker.sh`, luego la smoke test.
4. **Acceso directo a la lógica por URL** (`/Models/Database.php`, `/app/...`, `/.env`, `/composer.json`) → 404. Prueba: casos en `tests/smoke.sh` (Task 3).
5. **Endpoints protegidos sin sesión** (`DocenteController` sin login, o logueado como otro rol) → 401 JSON, no HTML ni fatal. Prueba: casos en `tests/smoke.sh` (Task 4).

---

## Mapa de archivos

| Ruta final | Origen / responsabilidad |
|---|---|
| `app/Models/*.php` | ← `public/Models/` (`auth.php` → `Auth.php`) |
| `app/Controllers/*.php` | ← `public/Controllers/` + nuevos `logoutController.php`, `DocenteController.php` |
| `app/views/*.php` | ← `public/views/*.php` |
| `app/api/api_registro.php` | ← `public/api/api_registro.php` |
| `public/index.html` | se queda; `Public/` → `assets/` |
| `public/views/login_usuario.html` | se queda (estático); `Public/` → `assets/` |
| `public/views/*.php`, `public/Controllers/*.php`, `public/api/api_registro.php` | puentes de 1 línea |
| `public/assets/{css,js,img}` | ← `public/Public/` |
| `database/01-schema.sql` | ← `sql/BaseDatos.sql` |
| `database/02-init-users.sh` | ← `docker/init-db.sh` |
| `docker/php/{Dockerfile,php.ini,docker-entrypoint.sh}` | Dockerfile corregido, `php.ini` ← `docker/php/config/php.ini`, entrypoint nuevo |
| `scripts/linux/` | ← `sh/*` + `public/api/procesar_reportes.sh` |
| `scripts/windows/` | ← `ps/*`; `scripts/windows/ejemplos/` ← `LAB6/*.toml` |
| `tests/smoke.sh` | nuevo: pruebas de humo HTTP contra `localhost:8080` |
| `composer.json`, `.env.example`, `docker-compose.yaml`, `.gitignore`, `.gitattributes`, `README.md` | raíz |

---

### Task 1: Mover a la estructura nueva y borrar lo colgado

**Files:**
- Move: todo lo listado en el mapa de archivos (con `git mv`).
- Delete: lista "Qué se borra" del spec, más `docker/init-db.sh`/`docker/php.ini`/`docker/php/config/` ya movidos o reemplazados.
- Create: `.gitattributes`
- Modify: `.gitignore`

**Interfaces:**
- Produces: la estructura del mapa de archivos. Las tareas siguientes asumen esas rutas exactas.

- [ ] **Step 1: Crear el tag de respaldo**

Run: `git tag pre-reorganizacion && git tag -l pre-reorganizacion`
Expected: imprime `pre-reorganizacion`.

- [ ] **Step 2: Escribir el chequeo de estructura (falla)**

Crear `tests/estructura.sh` (bash, `set -u`, sale con código ≠ 0 si algo falla, imprime cada fallo):
- Deben existir: `app/Models/Auth.php`, `app/Models/Database.php`, `app/Controllers/loginController.php`, `app/views/menu_docente.php`, `app/api/api_registro.php`, `public/index.html`, `public/views/login_usuario.html`, `public/assets/js/main.js`, `database/01-schema.sql`, `database/02-init-users.sh`, `docker/php/Dockerfile`, `docker/php/php.ini`, `scripts/linux/backup.sh`, `scripts/windows/Registro.ps1`, `doc/DOCKER_QUICK_START.md`.
- No deben existir: `assets/`, `src/`, `sql/`, `sh/`, `ps/`, `LAB6/`, `public/Public/`, `public/Models/`, `public/vendor/`, `public/composer.phar`, `public/Dockerfile`, `public/docker-compose.yml`, `docker-compose2.yaml`, `docker-compose copia.yaml`, `sglab.sql`, `SqlQuery_1.sql`, `env.example`, `test_session.php`, `test_session_read.php`, `DOCKER_QUICK_START.md` (raíz).
- `git ls-files | grep -E '\.DS_Store$|\.log$|(^|/)vendor/'` debe estar vacío.

Run: `bash tests/estructura.sh`
Expected: FAIL listando los faltantes.

- [ ] **Step 3: Ejecutar los movimientos y borrados**

`git mv` según el mapa (crear directorios destino antes). `public/views/login_usuario.html` **no** se mueve a `app/`. `.gitignore` final:

```
.vs/
.env
vendor/
*.log
.DS_Store
composer.phar
```

`.gitattributes`:

```
*.sh text eol=lf
```

- [ ] **Step 4: Correr el chequeo**

Run: `bash tests/estructura.sh`
Expected: sin salida de fallos, código 0.

- [ ] **Step 5: Commit**

```bash
git add -A && git commit -m "Reorganizo estructura del repo y borro carpetas colgadas"
```

---

### Task 2: Requires, puentes y assets

**Files:**
- Modify: `app/Models/*.php`, `app/Controllers/*.php`, `app/api/api_registro.php` (requires)
- Modify: `app/Models/Database.php:2,12-13`
- Modify: `public/index.html`, `public/views/login_usuario.html`, `app/views/*.php` (`Public/` → `assets/`)
- Create: `public/Controllers/{loginController,githubAuthController,usuariosController,RegistroController,EquipoController}.php`, `public/views/{menu_admin,menu_docente,menu_estudiante,panel_docente_laboratorios,equipos,usuarios,error,vinculacion_github}.php`, `public/api/api_registro.php` (puentes)
- Modify: `tests/estructura.sh` (nuevos chequeos)

**Interfaces:**
- Consumes: estructura de Task 1.
- Produces: cada archivo de `app/` se puede incluir desde cualquier directorio de trabajo. Formato de puente: `<?php require __DIR__ . '/../../app/<Carpeta>/<Archivo>.php';`

- [ ] **Step 1: Agregar chequeos a `tests/estructura.sh` (fallan)**

- `grep -rnE "require(_once)?\s*\(?\s*'" app` vacío (ningún require sin `__DIR__`).
- `grep -rn "models/\|Models/auth.php\|'\.\./vendor\|Public/" app public --include='*.php' --include='*.html' --include='*.js'` vacío (excluyendo `public/assets/js/jquery-3.7.1.js`).
- Por cada `app/Controllers/X.php` existente en Task 1 y cada `app/views/X.php`, existe `public/Controllers/X.php` / `public/views/X.php` y su contenido es exactamente la línea del puente.
- `public/api/api_registro.php` es puente a `app/api/api_registro.php`.

Run: `bash tests/estructura.sh`
Expected: FAIL.

- [ ] **Step 2: Corregir requires**

Todos a `require_once __DIR__ . '/<ruta relativa al archivo>'` con el casing real: en Models `__DIR__ . '/Database.php'`; en Controllers y api `__DIR__ . '/../Models/X.php'`; `Auth.php` con mayúscula. `Database.php`: autoload `__DIR__ . '/../../vendor/autoload.php'`; `Dotenv::createImmutable(__DIR__ . '/../../')->safeLoad()` en lugar de `->load()`; `required([...])` sin cambios. Los `require` de vendor en controllers (`'../vendor/autoload.php'`) → `__DIR__ . '/../../vendor/autoload.php'`.

- [ ] **Step 3: `Public/` → `assets/`** en `public/index.html`, `public/views/login_usuario.html` y `app/views/*.php` (reemplazo literal; las rutas relativas `../Public/` quedan `../assets/`).

- [ ] **Step 4: Crear los puentes** (uno por controller, vista PHP y api, con el formato de Interfaces).

- [ ] **Step 5: Correr el chequeo**

Run: `bash tests/estructura.sh`
Expected: código 0.

- [ ] **Step 6: Commit**

```bash
git add -A && git commit -m "Separo lógica del docroot con puentes y corrijo requires"
```

---

### Task 3: Docker, entrypoint y pruebas de humo

**Files:**
- Modify: `docker/php/Dockerfile`
- Create: `docker/php/docker-entrypoint.sh`
- Modify (reescribir): `docker-compose.yaml`
- Create: `.env.example`
- Modify (reescribir): `composer.json`; Create: `composer.lock` (generado en el contenedor)
- Modify: `start-docker.sh`, `start-docker.bat` (plantilla `.env.example`)
- Create: `tests/smoke.sh`

**Interfaces:**
- Consumes: estructura y puentes de Tasks 1–2.
- Produces: `tests/smoke.sh [BASE_URL]` (default `http://localhost:8080`), helpers `check_status <path> <code>` y `check_json <method> <path> <data> <jq-expr>` reutilizados por Task 4; sale con código ≠ 0 si falla algún caso.

- [ ] **Step 1: Escribir `tests/smoke.sh` (falla)**

Requiere `curl` y `jq`. Casos:
- `check_status / 200`, `/views/login_usuario.html 200`, `/assets/css/estilos.css 200`, `/assets/js/main.js 200`.
- `check_status /Models/Database.php 404`, `/app/Models/Database.php 404`, `/.env 404`, `/composer.json 404`, `/vendor/autoload.php 404`.
- `check_json POST /Controllers/loginController.php 'action=login&username=docente1&password=password' '.success == true'` (form-urlencoded, cookie jar en un tmp).
- `check_json POST /Controllers/loginController.php 'action=login&username=docente1&password=mala' '.success == false'`.

Run: `bash tests/smoke.sh`
Expected: FAIL (no hay contenedor).

- [ ] **Step 2: `composer.json` de la raíz**

`name: sglab/sistema-gestion`; `require`: `php >=8.1`, `ext-pdo`, `ext-mbstring`, `ext-curl`, `ext-json`, `spomky-labs/otphp ^11.3`, `paragonie/constant_time_encoding ^2.6`, `vlucas/phpdotenv ^5.5`. Sin `autoload`, sin `require-dev`, sin `post-install-cmd`. `config.sort-packages: true`, `config.platform.php: 8.3.0`. (`league/*` y `guzzle` no se usan: `githubAuthController` usa `curl_*`.)

- [ ] **Step 3: Dockerfile**

Según spec §Docker/Dockerfile, conservando los comentarios didácticos que sigan siendo ciertos. Extensiones: `pdo_mysql mbstring intl zip gd` (+ paquetes `libonig-dev libicu-dev libzip-dev libpng-dev unzip git`). DocumentRoot:

```dockerfile
ENV APACHE_DOCUMENT_ROOT=/var/www/sglab/public
RUN sed -ri 's!/var/www/html!${APACHE_DOCUMENT_ROOT}!g' /etc/apache2/sites-available/*.conf \
 && sed -ri 's!/var/www/!${APACHE_DOCUMENT_ROOT}!g' /etc/apache2/apache2.conf /etc/apache2/conf-available/*.conf
```

`COPY docker/php/php.ini /usr/local/etc/php/conf.d/custom.ini`, `COPY docker/php/docker-entrypoint.sh /usr/local/bin/`, `chmod +x`, `WORKDIR /var/www/sglab`, `ENTRYPOINT ["docker-entrypoint.sh"]`, `CMD ["apache2-foreground"]`. No copia el código (lo monta el compose). Healthcheck existente con `curl -f http://localhost/` se mantiene (instalar `curl`).

- [ ] **Step 4: `docker-entrypoint.sh`** exactamente como el bloque del spec §docker-entrypoint.sh.

- [ ] **Step 5: `docker-compose.yaml` y `.env.example`**

Según spec §docker-compose.yaml y §.env.example, con valores de `public/.env.example` del tag `pre-reorganizacion` (`git show pre-reorganizacion:public/.env.example`) y `MYSQL_ROOT_PASSWORD=root_password_123`, `MYSQL_DATABASE=bddsglab6`. Servicio `db` sin `ports:`. Healthcheck `db`: `["CMD-SHELL", "mysqladmin ping -h localhost -uroot -p$$MYSQL_ROOT_PASSWORD"]`, interval 5s, retries 20. Sin clave `version:`.

- [ ] **Step 6: `start-docker.sh` / `.bat`**: la lista de plantillas busca `.env.example` primero; compose `docker-compose.yaml`.

- [ ] **Step 7: Levantar desde cero y generar el lock**

Run:
```bash
rm -f composer.lock && cp -n .env.example .env
docker compose down -v && docker compose up --build -d
docker compose exec web composer update --no-interaction --no-dev
docker compose ps
```
Expected: `web`, `db`, `phpmyadmin` en `running` (db `healthy`); existe `composer.lock` y `vendor/autoload.php`.

- [ ] **Step 8: Lint y hash del seed**

Run: `docker compose exec web sh -c 'find app public -name "*.php" -exec php -l {} \; | grep -v "No syntax errors"'`
Expected: sin salida.
Run: `docker compose exec web php -r 'var_dump(password_verify("password","$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi"));'`
Expected: `bool(true)`. Si es `false`, parar y avisar (cambia la credencial de prueba).

- [ ] **Step 9: Smoke test**

Run: `bash tests/smoke.sh && docker compose logs web | grep -iE "fatal|error" ; true`
Expected: smoke en código 0; logs sin errores del entrypoint ni fatales de PHP.

- [ ] **Step 10: Review Focus 1 y 3**

Run: `file docker/php/docker-entrypoint.sh` → sin "CRLF".
Run: `rm .env && ./start-docker.sh` (o el equivalente no interactivo que ofrezca el script) `&& bash tests/smoke.sh`
Expected: `.env` recreado; smoke en código 0.

- [ ] **Step 11: Commit**

```bash
git add -A && git commit -m "Docker unificado con entrypoint funcional y smoke tests"
```

---

### Task 4: Controladores faltantes (logout y docente)

**Files:**
- Create: `app/Controllers/logoutController.php`, `app/Controllers/DocenteController.php`
- Create: `public/Controllers/logoutController.php`, `public/Controllers/DocenteController.php` (puentes)
- Modify: `tests/smoke.sh`

**Interfaces:**
- Consumes: `LaboratorioDocente` (`app/Models/LaboratorioDocente.php`): `new LaboratorioDocente('docente')`, `obtenerEstadisticas(): array`, `obtenerLaboratoriosConEquipos(): array`, `actualizarComentario($idLaboratorio, $comentario): bool`. Sesión: `$_SESSION['usuario_id']`, `$_SESSION['idTipoUsuario']`. Helpers `check_status`/`check_json` de Task 3.
- Produces: `GET /Controllers/DocenteController.php?action=obtenerEstadisticas|obtenerLaboratoriosConEquipos` → `{"success":true,"data":...}`; `POST ?action=actualizarComentario` con body JSON `{"idLaboratorio","comentario"}` → `{"success":bool,"message":string}`; `GET /Controllers/logoutController.php` → 302 a `../index.html`.

- [ ] **Step 1: Agregar casos a `tests/smoke.sh` (fallan)**

- Sin sesión: `GET DocenteController.php?action=obtenerEstadisticas` → status 401 y `.success == false`.
- Con sesión de `docente1` (cookie jar del login): `obtenerEstadisticas` → `.success == true and (.data | has("total_laboratorios"))`; `obtenerLaboratoriosConEquipos` → `.success == true and (.data | type == "array")`; `action=inexistente` → 400 y `.success == false`.
- Con sesión: `POST actualizarComentario` con el `id` del primer laboratorio de la respuesta anterior y `comentario: "smoke test"` → `.success == true`.
- Logout con la cookie: status 302 y header `Location` termina en `index.html`; después `obtenerEstadisticas` con la misma cookie → 401.

Run: `bash tests/smoke.sh`
Expected: FAIL en los casos nuevos (404).

- [ ] **Step 2: `logoutController.php`** según spec §Cambios de código 4.

- [ ] **Step 3: `DocenteController.php`** según spec §Cambios de código 5: headers JSON como `RegistroController.php` (sin `display_errors`), `session_start()`, guard `usuario_id` set y `idTipoUsuario == 2` → si no 401 `{"success":false,"message":"No autorizado"}`; `switch ($_GET['action'] ?? '')`; `actualizarComentario` lee `json_decode(file_get_contents('php://input'), true)`, valida `idLaboratorio` numérico (si no, 400); excepciones → 500 `{"success":false,"message":...}` y `error_log`.

- [ ] **Step 4: Puentes** en `public/Controllers/` para ambos.

- [ ] **Step 5: Correr**

Run: `docker compose exec web php -l app/Controllers/DocenteController.php && bash tests/smoke.sh`
Expected: sin errores de sintaxis; smoke en código 0.

- [ ] **Step 6: Verificación manual en navegador**

Login `docente1`/`password` en `http://localhost:8080` → panel docente muestra estadísticas y laboratorios; consola sin 404; botón salir vuelve a `/`.

- [ ] **Step 7: Commit**

```bash
git add -A && git commit -m "Agrego logoutController y DocenteController"
```

---

### Task 5: Documentación

**Files:**
- Modify: `README.md` (secciones Instalación con Docker, Configuración, Estructura del Proyecto)
- Modify: `doc/DOCKER_QUICK_START.md`, `doc/ARQUITECTURA_MVC.md` (árbol de carpetas)

**Interfaces:**
- Consumes: estructura y comandos finales de Tasks 1–4.

- [ ] **Step 1: Actualizar docs**

README: árbol de la sección "Estructura final" del spec; arranque `cp .env.example .env && docker compose up --build` (o `./start-docker.sh`); URLs `http://localhost:8080` y phpMyAdmin `:8081`; usuarios de prueba `docente1`/`password`; subsección "Reiniciar la base de datos" con `docker compose down -v`; cómo correr `bash tests/smoke.sh`. Quitar referencias a XAMPP con rutas viejas o ajustarlas a DocumentRoot `public/`.

- [ ] **Step 2: Verificar que no queden rutas viejas**

Run: `grep -nE "public-WEB|Public/|docker-compose2|/sql/|BaseDatos.sql|:80\b|tu-proyecto" README.md doc/*.md`
Expected: sin salida (salvo menciones intencionales explicadas).

- [ ] **Step 3: Corrida final completa**

Run: `docker compose down -v && docker compose up --build -d --wait && bash tests/estructura.sh && bash tests/smoke.sh`
Expected: ambos en código 0.

- [ ] **Step 4: Commit**

```bash
git add -A && git commit -m "Actualizo documentación con la estructura nueva"
```
