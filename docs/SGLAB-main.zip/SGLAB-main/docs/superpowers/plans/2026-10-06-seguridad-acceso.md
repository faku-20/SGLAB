# Seguridad y control de acceso — Plan de implementación

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Que cada vista y endpoint de SGLAB responda solo al rol correcto, sacar la clave API del código, no filtrar errores internos y cerrar los agujeros de los tres flujos de login (2FA salteable, OAuth sin `state`, fijación de sesión).

**Architecture:** Tres archivos nuevos en `app/Core/` (`entorno.php` → `respuestas.php` → `acceso.php`) que cada punto de entrada carga en su primera línea; las vistas y controladores llaman `requerirRolVista`/`requerirRolApi` con los roles de la matriz del spec. Los tests son scripts bash con curl contra el stack Docker (`tests/lib.sh` compartido).

**Tech Stack:** PHP 8.3 + Apache, MySQL 8, vlucas/phpdotenv, spomky-labs/otphp, Docker Compose, bash + curl + jq.

**Spec:** `docs/superpowers/specs/2026-10-06-seguridad-acceso-design.md`

## Global Constraints

- Rama `seguridad-acceso`. Stack levantado con `docker compose up -d --wait`; no hay PHP en el host (todo PHP vía `docker compose exec -T web`).
- Roles: `ROL_ADMIN = 1`, `ROL_DOCENTE = 2`, `ROL_ESTUDIANTE = 3`.
- JSON de error: `{"success": false, "message": "<texto>", "error": "<mismo texto>"}`; 401 `"No autenticado"`, 403 `"No autorizado"`, 500 BD `"Error interno del servidor"`.
- `APP_ENV === 'desarrollo'` es el único valor que muestra errores; ausente o cualquier otro → ocultos.
- Mensaje OAuth inválido: `La solicitud de inicio de sesión no es válida o expiró. Intentá nuevamente.`
- Mensaje 2FA sin paso previo: `Sesión de login expirada. Ingrese nuevamente usuario y contraseña.`
- Ningún archivo que cargue `entorno.php` llama `session_start()` por su cuenta (generaría un Notice visible en desarrollo).
- Los puentes de `public/` no cambian. `tests/estructura.sh` y `tests/smoke.sh` siguen en verde al final de cada tarea.
- Commits en español terminados con `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`.

## Review Focus

1. **Estudiante logueado de verdad** (vía GitHub) abre `menu_estudiante.php` y reporta un equipo → debe seguir andando; no hay sesión de estudiante automatizable. Prueba: Task 2 agrega en `seguridad.sh` una sesión de estudiante sembrada (`sesion_estudiante` crea el archivo de sesión PHP en el contenedor) y verifica `menu_estudiante` 200 y `obtenerEquipos` 200.
2. **Código TOTP en el borde de los 30 s** → el login de admin del test no debe fallar intermitentemente. Prueba: Task 2, `login_admin` reintenta una vez si `verify_2fa` responde `success:false`.
3. **Login con la base caída** → la pantalla de login muestra un error entendible, no un JSON crudo ni un fatal. Prueba: Task 4, `errores.sh` verifica 500 con `.message == "Error interno del servidor"`.
4. **`.env` viejo sin `APP_ENV` ni `API_KEY`** (clones previos) → la app anda con errores ocultos y la API responde 500 "API no configurada", no 401 ni fatal. Prueba: Task 1 (APP_ENV ausente → `display_errors` 0) y Task 5 (API_KEY vacía → mensaje).
5. **Reportes de estudiante: `crearReporte` sigue grabando `idUsuario` de la sesión** tras quitar el `session_start` propio de `RegistroController`. Prueba: Task 2, con la sesión sembrada de estudiante `POST crearReporte` → `.success == true`.

---

## Mapa de archivos

| Archivo | Responsabilidad |
|---|---|
| `app/Core/entorno.php` (nuevo) | autoload, `.env`, `display_errors` por `APP_ENV`, cookie de sesión, `session_start`, `ES_DESARROLLO` |
| `app/Core/respuestas.php` (nuevo) | `responderJson`, `responderExcepcion` |
| `app/Core/acceso.php` (nuevo) | constantes de rol, `rolActual`, `requerirRolVista`, `requerirRolApi` |
| `app/views/*.php`, `app/Controllers/*.php`, `app/api/api_registro.php` | usan los anteriores |
| `app/Models/Database.php` | excepción sin SQLSTATE |
| `docker/php/php.ini`, `.env.example` | `display_errors=Off`, `APP_ENV`, `API_KEY` |
| `scripts/linux/procesar_reportes.sh` | `API_URL`/`API_KEY` del entorno |
| `tests/lib.sh` (nuevo) | helpers HTTP compartidos |
| `tests/seguridad.sh` (nuevo), `tests/errores.sh` (nuevo) | pruebas de acceso, login, API, CORS, errores |
| `tests/smoke.sh`, `tests/estructura.sh` | `source tests/lib.sh`; chequeos estáticos nuevos |
| `README.md`, `doc/ARQUITECTURA_MVC.md` | sección Seguridad, `app/Core/` |

---

### Task 1: Núcleo (`entorno`, `respuestas`, `acceso`) y `tests/lib.sh`

**Files:**
- Create: `app/Core/entorno.php`, `app/Core/respuestas.php`, `app/Core/acceso.php`, `tests/lib.sh`, `tests/seguridad.sh`
- Modify: `tests/smoke.sh` (mover helpers a `lib.sh`, `source` al inicio), `docker/php/php.ini` (`display_errors = Off`, `display_startup_errors = Off`), `.env.example` (`APP_ENV=desarrollo` con comentario "usar produccion en el servidor del laboratorio"), `.env` local (agregar `APP_ENV=desarrollo`)

**Interfaces:**
- Produces:
  - `entorno.php`: define `ES_DESARROLLO` (bool); deja la sesión iniciada.
  - `respuestas.php`: `responderJson(int $codigo, array $datos): never`; `responderExcepcion(Throwable $e): never` (PDOException → 500 `"Error interno del servidor"` + `detalle` si `ES_DESARROLLO`; otra → 400 con `$e->getMessage()`; siempre `success:false` y `error` = `message`).
  - `acceso.php`: `ROL_ADMIN|ROL_DOCENTE|ROL_ESTUDIANTE`, `rolActual(): ?int`, `requerirRolVista(array $roles): void`, `requerirRolApi(array $roles): void`.
  - `tests/lib.sh`: `BASE`, `COOKIES` (sobrescribible), `ok`, `fallo`, `check_status`, `check_json`, `check_page`, `check_redirect`, `terminar` (imprime resultado y sale con código).

- [ ] **Step 1: Extraer `tests/lib.sh` y verificar que smoke sigue igual**

`lib.sh` contiene todo lo que hoy está en `smoke.sh` desde `BASE=` hasta `check_redirect` inclusive, más `terminar() { [ "$fallos" -eq 0 ] || { echo "$fallos fallo(s)"; exit 1; }; echo "${1:-OK}"; }`. `smoke.sh` queda: shebang, `source "$(dirname "$0")/lib.sh"`, los casos, `terminar "smoke OK"`.

Run: `bash tests/smoke.sh | tail -1`
Expected: `smoke OK`.

- [ ] **Step 2: Escribir `tests/seguridad.sh` con el caso de `APP_ENV` (falla)**

```bash
source "$(dirname "$0")/lib.sh"
# check_display_errors <valor APP_ENV o 'ausente'> <esperado>
# corre: docker compose exec -T [-e APP_ENV=<v>] web php -r 'require "app/Core/entorno.php"; echo ini_get("display_errors") ? "1" : "0";'
check_display_errors desarrollo 1
check_display_errors produccion 0
check_display_errors ausente 0
terminar "seguridad OK"
```

Para `ausente` usar `-e APP_ENV=` y que `entorno.php` trate vacío igual que ausente.

Run: `bash tests/seguridad.sh`
Expected: FAIL (`app/Core/entorno.php` no existe).

- [ ] **Step 3: Implementar los tres archivos de `app/Core/`** según Interfaces y la sección "Componentes nuevos" del spec. `entorno.php` lee `APP_ENV` con `$_ENV['APP_ENV'] ?? getenv('APP_ENV') ?: ''`. `acceso.php` hace `require_once __DIR__ . '/entorno.php'` y `'/respuestas.php'`. `requerirRolVista` redirige a `login_usuario.html` (relativo: todas las vistas viven en `/views/`).

- [ ] **Step 4: `php.ini` y `.env`**: aplicar los cambios de Files; `docker compose up -d --build --wait` (php.ini se copia en el build).

- [ ] **Step 5: Correr**

Run: `bash tests/seguridad.sh && bash tests/smoke.sh | tail -1 && bash tests/estructura.sh`
Expected: `seguridad OK`, `smoke OK`, `estructura OK`.

- [ ] **Step 6: Commit** — `git add -A && git commit -m "Agrego núcleo de entorno, respuestas y acceso"`

---

### Task 2: Control de acceso por rol y CORS

**Files:**
- Modify: `app/views/{menu_admin,equipos,usuarios,menu_docente,panel_docente_laboratorios,menu_estudiante}.php`, `app/views/{error,vinculacion_github}.php` (solo `entorno.php`), `app/Controllers/{EquipoController,usuariosController,RegistroController,DocenteController}.php`
- Modify: `tests/seguridad.sh`, `tests/estructura.sh`

**Interfaces:**
- Consumes: `acceso.php` de Task 1.
- Produces (en `seguridad.sh`, para Tasks 3–5): `login_docente <jar>`, `login_admin <jar>` (contraseña + TOTP, con un reintento), `secreto_admin` (stdout: secret de la respuesta o de `Usuarios.secret_2fa`), `totp_ahora <secret>` (stdout: código vía `OTPHP\TOTP::create($secret)->now()` en el contenedor), `sesion_estudiante <jar>` (siembra sesión de estudiante, ver Step 1).

- [ ] **Step 1: Agregar casos a `seguridad.sh` (fallan)**

`sesion_estudiante`: elige un id de sesión aleatorio, escribe con `docker compose exec -T web php -r` el archivo `/var/lib/php/sessions/sess_<id>` con `session_encode()` de `['usuario_id'=>6,'idTipoUsuario'=>3]` (id 6 = `juan.perez`, verificar con `SELECT id FROM Usuarios WHERE username='juan.perez'`), `chown www-data`, y agrega la cookie `PHPSESSID=<id>` al jar.

Casos (jar nuevo por bloque):
- Sin sesión: `check_redirect /views/{menu_admin,equipos,usuarios,menu_estudiante}.php login_usuario.html`; `check_json GET /Controllers/EquipoController.php?action=obtenerTodos '' '.success == false and .message == "No autenticado"' 401`; ídem `POST EquipoController.php?action=crearEquipo '{}'`, `usuariosController.php?action=obtenerUsuarios`, `RegistroController.php?action=obtenerTodosRegistros`, `RegistroController.php?action=obtenerEquipos` → 401.
- Docente: los mismos endpoints → 403 `.message == "No autorizado"`; vistas admin y `menu_estudiante` → `check_redirect … login_usuario.html`; `DocenteController.php?action=obtenerEstadisticas` → 200.
- Admin (`login_admin`): `check_page /views/{menu_admin,equipos,usuarios,menu_docente,panel_docente_laboratorios}.php`; `EquipoController?action=obtenerTodos`, `usuariosController?action=obtenerUsuarios`, `RegistroController?action=obtenerTodosRegistros`, `DocenteController?action=obtenerEstadisticas` → 200 `.success == true`; `POST RegistroController?action=crearReporte '{}'` → 403; `menu_estudiante` → redirect login.
- Estudiante (`sesion_estudiante`): `check_page /views/menu_estudiante.php`; `RegistroController?action=obtenerEquipos` → 200 `.success == true`; `POST crearReporte` con un `idEquipo` válido (el primero de `obtenerEquipos`) y los campos que manda `menu_estudiante.js:71` → `.success == true`; `EquipoController?action=obtenerTodos` → 403; vistas admin → redirect login.
- CORS: `curl -sI` a `loginController.php` (POST) y `EquipoController.php` sin `Access-Control-Allow-Origin` en los headers.

Agregar a `estructura.sh`:
- cada `app/views/*.php` y `app/Controllers/*.php` contiene `requerirRolVista(` o `requerirRolApi(`, salvo `loginController.php`, `githubAuthController.php`, `logoutController.php`, `error.php`, `vinculacion_github.php`;
- `grep -rn "Access-Control-Allow" app` vacío;
- `grep -rn "session_start()" app/views app/Controllers` vacío.

Run: `bash tests/seguridad.sh; bash tests/estructura.sh`
Expected: FAIL en los casos nuevos.

- [ ] **Step 2: Vistas** — reemplazar el bloque `session_start()` + verificación (+ los `error_log` de sesión) por `require_once __DIR__ . '/../Core/acceso.php';` y `requerirRolVista([...])` según la matriz del spec. `error.php` y `vinculacion_github.php`: reemplazar su `session_start` condicional por `require_once __DIR__ . '/../Core/entorno.php';`.

- [ ] **Step 3: Controladores** — `require_once __DIR__ . '/../Core/acceso.php';` como primera línea; quitar `session_start()`, `Access-Control-*` y el bloque `OPTIONS`; `EquipoController`/`usuariosController`: `requerirRolApi([ROL_ADMIN])` (en `usuariosController` reemplaza el chequeo 403 actual); `DocenteController`: `requerirRolApi([ROL_ADMIN, ROL_DOCENTE])` en lugar de su `if` y de su función `responder` (usar `responderJson`); `RegistroController`: mapa `$permisos` del spec y `requerirRolApi($permisos[$_GET['action'] ?? ''] ?? [ROL_ADMIN])`, quitando el chequeo de sesión propio de `crearReporte` (sigue leyendo `$_SESSION['usuario_id']`).

- [ ] **Step 4: Correr**

Run: `bash tests/seguridad.sh && bash tests/smoke.sh | tail -1 && bash tests/estructura.sh`
Expected: los tres en verde.

- [ ] **Step 5: Commit** — `git commit -am "Control de acceso por rol en vistas y controladores; quito CORS"` (más `git add` de archivos nuevos si los hay)

---

### Task 3: Endurecer los tres logins

**Files:**
- Modify: `app/Controllers/loginController.php`, `app/Controllers/githubAuthController.php`, `app/Controllers/logoutController.php` (solo `entorno.php` en vez de `session_start`)
- Modify: `tests/seguridad.sh`, `tests/estructura.sh`

**Interfaces:**
- Consumes: `entorno.php`; helpers `login_admin`, `secreto_admin`, `totp_ahora` de Task 2.

- [ ] **Step 1: Casos nuevos (fallan)**

- Bypass 2FA: jar nuevo, `secreto_admin` ya configurado (correr después del bloque admin), `POST loginController.php 'action=verify_2fa&user_id=<id sysadmin>&code=<totp_ahora>'` → `.success == false and .message == "Sesión de login expirada. Ingrese nuevamente usuario y contraseña."`. Ídem `action=setup_2fa`.
- Fijación: jar nuevo; login docente con contraseña mala → leer `PHPSESSID` del jar; login correcto → `PHPSESSID` distinto. Lo mismo para admin tras `verify_2fa`.
- OAuth: `check_redirect '/Controllers/githubAuthController.php?code=x&state=malo' views/error.php`, ídem `?code=x`; luego `GET /views/error.php` con el mismo jar contiene `no es válida o expiró`. Para `state=malo` usar un jar que antes pasó por el paso 1 (GET sin `code`), así hay `oauth_state` en sesión y el caso prueba la comparación.

`estructura.sh`: `grep -rnE 'print_r\(\$_(POST|SESSION)|error_log\("[^"]*\$(secret|qrCode)\b' app` vacío; `grep -rn "session_start()" app/Controllers` vacío (logout incluido).

Run: `bash tests/seguridad.sh; bash tests/estructura.sh`
Expected: FAIL en estos casos.

- [ ] **Step 2: `loginController.php`**
  - Primera línea `require_once __DIR__ . '/../Core/entorno.php';`; quitar `session_start`, headers CORS/OPTIONS, `error_log("POST data: …")`, `error_log("Secret generado: …")`.
  - En la rama admin (tras contraseña válida): `$_SESSION['2fa_pendiente'] = $usuario->getId();`.
  - `verify_2fa` y `setup_2fa`: `$userId = $_SESSION['2fa_pendiente'] ?? null;` (no leer `$_POST['user_id']`); si es `null` → `sendJsonResponse(false, 'Sesión de login expirada. Ingrese nuevamente usuario y contraseña.')`. Tras código válido `unset($_SESSION['2fa_pendiente'])` antes de `crearSesion`.
  - `crearSesion()`: `session_regenerate_id(true)` como primera línea.

- [ ] **Step 3: `githubAuthController.php`**
  - Primera línea `entorno.php`; quitar `session_start`, `use Dotenv` y su carga de `.env` (lo hace `entorno.php`).
  - Paso 1: guardar el `state` generado en `$_SESSION['oauth_state']` antes del redirect.
  - Paso 2 (antes de intercambiar el `code`): si no hay `oauth_state` en sesión, no hay `$_GET['state']`, o `!hash_equals($_SESSION['oauth_state'], $_GET['state'])` → `unset`, `$_SESSION['error_mensaje'] = '<mensaje OAuth de Global Constraints>'`, `header('Location: ../views/error.php')`, `exit`. Si coincide, `unset($_SESSION['oauth_state'])` y seguir.
  - `crearSesionEstudiante()`: `session_regenerate_id(true)` primero.

- [ ] **Step 4: `logoutController.php`** — `require_once __DIR__ . '/../Core/entorno.php';` en lugar de `session_start()`.

- [ ] **Step 5: Correr**

Run: `bash tests/seguridad.sh && bash tests/smoke.sh | tail -1 && bash tests/estructura.sh`
Expected: verde.

- [ ] **Step 6: Verificación manual del login admin en el JS**: `public/assets/js/main_login_usuario.js` sigue enviando `user_id`; confirmar con `grep -n "user_id" public/assets/js/main_login_usuario.js` que no depende de la respuesta para otra cosa que mostrar el paso 2FA (sin cambios de código esperados).

- [ ] **Step 7: Commit** — `git commit -am "Endurezco login: 2FA ligado a la sesión, state OAuth, regenerate_id, sin secretos en logs"`

---

### Task 4: Errores sin filtrar detalles internos

**Files:**
- Modify: `app/Models/Database.php`, `catch` de `app/Controllers/{EquipoController,RegistroController,usuariosController,DocenteController,loginController}.php`
- Create: `tests/errores.sh`

**Interfaces:**
- Consumes: `responderExcepcion` de Task 1.

- [ ] **Step 1: `tests/errores.sh` (falla)**

```bash
source "$(dirname "$0")/lib.sh"
trap 'docker compose start db >/dev/null; docker compose up -d --wait >/dev/null' EXIT
docker compose stop db >/dev/null
check_json POST /Controllers/loginController.php 'action=login&username=docente1&password=password' \
  '.success == false and .message == "Error interno del servidor" and (.message | test("SQLSTATE") | not) and has("detalle")' 500
terminar "errores OK"
```

Run: `bash tests/errores.sh`
Expected: FAIL (hoy responde 200 con "Error en el servidor: …SQLSTATE…").

- [ ] **Step 2: `Database.php`** — en el `catch (PDOException $e)` de la conexión: `error_log` del mensaje PDO y relanzar `PDOException('No se pudo conectar a la base de datos', 0, $e)` (sigue siendo `PDOException` para que `responderExcepcion` la clasifique como error interno).

- [ ] **Step 3: Controladores** — cada `catch (Exception $e)` que responde `$e->getMessage()` pasa a `catch (Throwable $e) { error_log(...); responderExcepcion($e); }`. En `loginController`, el `catch` general deja de usar `sendJsonResponse(false, 'Error en el servidor: ' …)`. En los modelos, revisar con `grep -rn "throw new Exception" app/Models` que ninguno arme el mensaje con `$e->getMessage()` de PDO; si alguno lo hace, relanzar la `PDOException` original en su lugar.

Si `Auth::loginByUsername` atrapa la `PDOException` y devuelve `null` (login "incorrecto" en vez de error), hacer que la relance para que llegue al `catch` del controlador.

- [ ] **Step 4: Correr**

Run: `bash tests/errores.sh && bash tests/seguridad.sh && bash tests/smoke.sh | tail -1 && bash tests/estructura.sh`
Expected: verde.

- [ ] **Step 5: Commit** — `git add -A && git commit -m "Errores de base de datos sin detalles al cliente"`

---

### Task 5: Clave API fuera del código

**Files:**
- Modify: `app/api/api_registro.php`, `.env.example`, `.env` local, `scripts/linux/procesar_reportes.sh`, `tests/seguridad.sh`, `tests/estructura.sh`

- [ ] **Step 1: Casos (fallan)**

En `seguridad.sh`:
- `POST /api/api_registro.php` sin header → 401; con `X-API-KEY: incorrecta` → 401.
- `GET /api/api_registro.php` con `X-API-KEY: <API_KEY de .env>` → 405.
- `docker compose exec -T -e API_KEY= -e REQUEST_METHOD=POST web php app/api/api_registro.php` → stdout contiene `API no configurada`.

`check_json` no manda headers: agregar en `lib.sh` la variable opcional `EXTRA_HEADER` (si no está vacía, se pasa como `-H "$EXTRA_HEADER"`).

En `estructura.sh`: `grep -rn "TU_CLAVE_SECRETA" --exclude-dir=.git --exclude-dir=docs --exclude-dir=tests .` vacío.

Run: `bash tests/seguridad.sh; bash tests/estructura.sh`
Expected: FAIL.

- [ ] **Step 2: Implementar** según spec §Clave API: `api_registro.php` carga `entorno.php`, quita el `define`, valida con `$_ENV['API_KEY'] ?? ''` y `hash_equals`; `.env.example` agrega `API_KEY=` con comentario `# Generar con: openssl rand -hex 32 (la clave vieja del repo es pública: no reutilizar)`; `.env` local recibe una clave generada con `openssl rand -hex 32`; `procesar_reportes.sh` usa `API_URL="${API_URL:-http://localhost:8080/api/api_registro.php}"` y `API_KEY="${API_KEY:?Definí API_KEY (la misma que en .env)}"`. Reiniciar `web` (`docker compose up -d --force-recreate --wait web`) para que tome el `.env`.

- [ ] **Step 3: Correr**

Run: `bash tests/seguridad.sh && bash tests/smoke.sh | tail -1 && bash tests/estructura.sh`
Expected: verde.

- [ ] **Step 4: Commit** — `git commit -am "Clave API desde .env; script de reportes configurable"`

---

### Task 6: Documentación y corrida final

**Files:**
- Modify: `README.md`, `doc/ARQUITECTURA_MVC.md`

- [ ] **Step 1: README** — sección "🔒 Seguridad" (después de "Configuración"): tabla de roles (qué ve cada uno, de la matriz del spec), `APP_ENV` (`desarrollo` vs `produccion`), `API_KEY` (cómo generarla, que la vieja es pública), prueba manual del login de estudiante con una OAuth App real, cómo correr `tests/seguridad.sh` y `tests/errores.sh` (este último detiene la base unos segundos). `ARQUITECTURA_MVC.md`: agregar `app/Core/` (entorno, respuestas, acceso) al árbol.

- [ ] **Step 2: Corrida final desde cero**

Run: `docker compose down -v && docker compose up --build -d --wait && bash tests/estructura.sh && bash tests/smoke.sh && bash tests/seguridad.sh && bash tests/errores.sh`
Expected: los cuatro en verde (con base nueva, el admin pasa por `needs_setup`).

Run: `bash tests/seguridad.sh | tail -1`
Expected: `seguridad OK` (segunda corrida: admin ya configurado, rama `verify_2fa`).

- [ ] **Step 3: Commit** — `git commit -am "Documento seguridad y roles"`
