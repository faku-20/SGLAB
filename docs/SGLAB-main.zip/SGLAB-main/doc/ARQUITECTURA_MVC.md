# ARQUITECTURA MVC - SISTEMA DE GESTIÓN DE LABORATORIO

## 1. ESTRUCTURA GENERAL DEL PROYECTO

```
SGLAB/
├── app/                            # Lógica (fuera del docroot)
│   ├── Core/                       # Base común
│   │   ├── entorno.php             # .env, APP_ENV (errores), sesión
│   │   ├── respuestas.php          # responderJson / responderExcepcion
│   │   └── acceso.php              # roles: requerirRolVista / requerirRolApi
│   ├── Models/                     # CAPA DE MODELOS
│   │   ├── Database.php            # Singleton para conexión BD (lee .env de la raíz)
│   │   ├── Usuario.php             # Modelo de usuarios
│   │   ├── Equipo.php              # Modelo de equipos/PCs
│   │   ├── Registro.php            # Modelo de registros
│   │   ├── Laboratorio.php         # Modelo de laboratorios
│   │   ├── LaboratorioDocente.php  # Consultas del panel docente
│   │   ├── TipoUsuario.php         # Tipos de usuario
│   │   └── Auth.php                # Autenticación y 2FA
│   ├── Controllers/                # CAPA DE CONTROLADORES
│   │   ├── loginController.php     # Login y 2FA
│   │   ├── logoutController.php    # Cierre de sesión
│   │   ├── DocenteController.php   # API del panel docente
│   │   ├── EquipoController.php    # CRUD equipos
│   │   ├── RegistroController.php  # Gestión registros
│   │   ├── usuariosController.php  # CRUD usuarios
│   │   └── githubAuthController.php # OAuth GitHub
│   ├── views/                      # CAPA DE VISTAS
│   │   ├── menu_admin.php          # Panel administrador
│   │   ├── menu_docente.php        # Panel docentes
│   │   ├── panel_docente_laboratorios.php
│   │   ├── menu_estudiante.php     # Panel estudiantes
│   │   ├── equipos.php             # Gestión de equipos
│   │   └── usuarios.php            # Gestión de usuarios
│   └── api/api_registro.php        # Registro de equipos desde scripts
│
├── public/                         # DocumentRoot (único accesible por web)
│   ├── index.html                  # Página de inicio
│   ├── views/login_usuario.html    # Página de login
│   ├── Controllers/, views/, api/  # Puentes de una línea → app/
│   └── assets/{css,js,img}         # RECURSOS ESTÁTICOS
│
├── database/01-schema.sql          # Script SQL
├── .env                            # Configuración (no va a Git; plantilla .env.example)
└── composer.json                   # Dependencias PHP
```

---

## 2. TABLAS DE BASE DE DATOS (bddsglab6)

### Tabla: Usuarios
