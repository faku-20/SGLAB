#!/usr/bin/env bash
set -u

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

compose_file=""
for candidate in docker-compose.yaml docker-compose.yml; do
    if [ -f "$candidate" ]; then
        compose_file="$candidate"
        break
    fi
done

if [ -z "$compose_file" ]; then
    echo -e "${RED}[ERROR]${NC} No se encontró un archivo docker-compose.yaml ni docker-compose.yml en el proyecto."
    exit 1
fi

env_file=".env"
if [ ! -f "$env_file" ]; then
    for template in .env.example; do
        if [ -f "$template" ]; then
            cp "$template" "$env_file"
            echo -e "${YELLOW}[INFO]${NC} Se creó $env_file a partir de $template."
            break
        fi
    done
fi

if [ ! -f "$env_file" ]; then
    echo -e "${RED}[ERROR]${NC} No existe un archivo .env y no se encontró una plantilla válida."
    echo "Crea .env con las variables de entorno antes de iniciar los contenedores."
    exit 1
fi

compose_cmd=()
if docker compose version >/dev/null 2>&1; then
    compose_cmd=(docker compose)
elif command -v docker-compose >/dev/null 2>&1; then
    compose_cmd=(docker-compose)
else
    echo -e "${RED}[ERROR]${NC} Docker Compose no está instalado o no está disponible en el PATH."
    echo "Instálalo desde: https://docs.docker.com/compose/install/"
    exit 1
fi

cmd="${1:-start}"

case "$cmd" in
    start)
        echo "======================================"
        echo "Sistema de Gestión de Laboratorios"
        echo "======================================"
        echo ""
        echo -e "${YELLOW}[INFO]${NC} Levantando servicios con $compose_file..."
        "${compose_cmd[@]}" --env-file "$env_file" -f "$compose_file" up -d --build
        echo ""
        echo "======================================"
        echo -e "${GREEN}Servicios iniciados correctamente.${NC}"
        echo "======================================"
        echo ""
        echo -e "Aplicación: ${GREEN}http://localhost:8080${NC}"
        echo -e "phpMyAdmin: ${GREEN}http://localhost:8081${NC}"
        echo ""
        echo "Comandos útiles:"
        echo "  Ver logs:      ${compose_cmd[*]} --env-file $env_file -f $compose_file logs -f"
        echo "  Detener:       ${compose_cmd[*]} --env-file $env_file -f $compose_file down"
        echo "  Reiniciar:     ${compose_cmd[*]} --env-file $env_file -f $compose_file restart"
        ;;
    stop)
        echo -e "${YELLOW}[INFO]${NC} Deteniendo servicios..."
        "${compose_cmd[@]}" --env-file "$env_file" -f "$compose_file" down
        ;;
    logs)
        "${compose_cmd[@]}" --env-file "$env_file" -f "$compose_file" logs -f
        ;;
    *)
        echo "Uso: $0 [start|stop|logs]"
        exit 1
        ;;
esac
