#!/bin/sh
# Entrypoint del contenedor web: prepara dependencias y directorios, y lanza el CMD (apache2-foreground).
set -e
cd /var/www/sglab

# El código se monta como volumen: vendor/ puede faltar o estar desactualizado
# respecto de composer.lock. Si ya está al día, composer install no hace nada.
composer install --no-interaction --no-dev --optimize-autoloader

# Directorio usado por la API de registro para mover y procesar reportes.
mkdir -p /var/www/sglab/app/reportes_para_procesar
chown -R www-data:www-data /var/www/sglab/app/reportes_para_procesar

mkdir -p /var/log/sglab /var/lib/php/sessions
chown -R www-data:www-data /var/log/sglab /var/lib/php/sessions

exec "$@"
